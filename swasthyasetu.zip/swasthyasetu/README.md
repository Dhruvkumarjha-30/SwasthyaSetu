# स्वास्थ्यसेतु (SwasthyaSetu) — Telemedicine & Healthcare Access Platform

**SwasthyaSetu (स्वास्थ्यसेतु)** connects patients in rural India and underserved communities with qualified, state-council-registered doctors. It provides multilingual symptom intake, secure private document storage for blood reports and prescriptions, explicit doctor assignment, doctor-authored clinical reports, and automated notifications.

---

## 🏗️ Architecture Overview

- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS with royal-purple-and-lavender design tokens.
- **Backend & Database**: Supabase (PostgreSQL 15+).
- **Security & Authorization**: Row Level Security (RLS) on all tables + database-level triggers preventing privilege escalation.
- **Medical File Storage**: Supabase Private Storage (`patient-documents` and `doctor-qualifications`) with signed URL access.
- **Email Notifications**: Supabase Edge Function (`send-report-email`) invoking Resend API without exposing secrets to client browsers.

---

## 📁 Repository Structure

```
swasthyasetu/
├── .env.example                                  # Template for environment configuration
├── index.html                                    # Royal purple themed HTML entry point
├── package.json                                  # Project dependencies and test scripts
├── vite.config.ts                                # Vite development and bundling configuration
├── supabase/
│   ├── migrations/
│   │   ├── 20261010000001_initial_schema.sql     # Schema: profiles, cases, documents, reports, ratings
│   │   ├── 20261010000002_row_level_security.sql # Strict RLS policies for patient-doctor isolation
│   │   ├── 20261010000003_storage_buckets.sql    # Private storage buckets: patient-documents, qualifications
│   │   ├── 20261010000004_triggers_and_functions.sql # User sync, privilege escalation checks, notifications
│   │   └── 20261010000005_seed_data.sql          # Seed doctors (Dr. Asha Verma, Dr. Rohan Mehta, etc.)
│   └── functions/
│       └── send-report-email/
│           ├── index.ts                          # Deno Edge Function for Resend email delivery
│           └── README.md                         # Edge function deployment instructions
└── src/
    ├── App.tsx                                   # Main React router and layout container
    ├── index.css                                 # Royal purple & lavender design system
    ├── lib/
    │   ├── supabase.ts                           # Supabase client with fallback demo handling
    │   └── i18n.ts                               # Bilingual English & Hindi translation dictionaries
    ├── contexts/
    │   ├── AuthContext.tsx                       # Session & demo role state management
    │   └── LanguageContext.tsx                   # English / Hindi language toggle
    ├── services/
    │   ├── auth.ts                               # Supabase Auth integration
    │   ├── cases.ts                              # Patient case lifecycle management
    │   ├── doctors.ts                            # Doctor directory queries & filters
    │   ├── documents.ts                          # Private file upload & signed URL generation
    │   ├── reports.ts                            # Doctor report drafting & release
    │   ├── ratings.ts                            # Ratings & reviews submission (1-5 stars)
    │   └── notifications.ts                      # In-app notifications
    ├── components/
    │   ├── Navbar.tsx                            # Top navigation with language toggle & demo switcher
    │   ├── Footer.tsx                            # Footer with emergency numbers (108) & disclaimers
    │   ├── EmergencyBanner.tsx                   # Crimson alert for acute red-flag symptoms
    │   ├── DoctorCard.tsx                        # Verified doctor credentials & consult trigger
    │   ├── DocumentUpload.tsx                    # Drag-and-drop secure document uploader
    │   ├── StarRating.tsx                        # Accessible star rating selector
    │   └── StatusBadge.tsx                       # Consultation lifecycle status badge
    ├── pages/
    │   ├── Home.tsx                              # Hero landing page & 4 core pillars
    │   ├── HowItWorks.tsx                        # 4-step walkthrough for rural users
    │   ├── FindDoctors.tsx                       # Search by specialty, language, and rating
    │   ├── SymptomTriage.tsx                     # Bilingual health questionnaire & intake form
    │   ├── AuthPage.tsx                          # Patient & Doctor registration and login
    │   ├── PatientDashboard.tsx                  # Case tracking, report viewer & rating submission
    │   ├── DoctorDashboard.tsx                   # Assigned cases, patient queue, & report authoring
    │   ├── AboutUs.tsx                           # Healthcare mission & telemedicine compliance
    │   └── SetupGuide.tsx                        # In-app interactive Supabase configuration guide
    └── tests/
        ├── rls_policy_rules.test.ts              # RLS isolation verification rules
        ├── case_status_machine.test.ts           # State machine lifecycle tests
        ├── validation.test.ts                    # Input validation and file size tests
        └── run_tests.ps1                         # PowerShell test runner (21/21 passing)
```

---

## 🚀 How to Run Locally

1. **Install Node.js** (v18 or v20 LTS) from [nodejs.org](https://nodejs.org).
2. Open terminal in the project directory:
   ```bash
   cd swasthyasetu
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start development server:
   ```bash
   npm run dev
   ```
5. Open your browser at `http://localhost:5173`.
   * Even without Supabase credentials configured initially, the frontend runs in an **Interactive Demo Mode** allowing complete testing of both patient and doctor experiences!

---

## 🔒 Security Best Practices

1. **Service Role Key**: Never put the `service_role` key in frontend `.env` files. It bypasses Row Level Security.
2. **Medical Privacy**: Notification emails never contain sensitive medical diagnoses or drug prescriptions. They provide a secure link to authenticate and review the report.
3. **Storage Security**: Storage buckets are marked `public = false`. File access is granted only via short-lived signed URLs generated on-demand.

import React, { useState } from 'react';
import { documentService, MAX_FILE_SIZE, ALLOWED_MIME_TYPES } from '../services/documents';
import { MedicalDocument, MedicalDocumentType } from '../types';
import { UploadCloud, FileText, CheckCircle2, AlertCircle, X, Lock } from 'lucide-react';

interface DocumentUploadProps {
  patientId: string;
  caseId?: string | null;
  onUploaded: (doc: MedicalDocument) => void;
}

export const DocumentUpload: React.FC<DocumentUploadProps> = ({ patientId, caseId, onUploaded }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [docType, setDocType] = useState<MedicalDocumentType>('blood_report');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFile(e.target.files[0]);
    }
  };

  const processSelectedFile = (file: File) => {
    setError(null);
    const validation = documentService.validateFile(file);
    if (!validation.valid) {
      setError(validation.error || 'Invalid file');
      setSelectedFile(null);
      return;
    }
    setSelectedFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    setError(null);

    const result = await documentService.uploadDocument({
      file: selectedFile,
      patientId,
      caseId,
      documentType: docType
    });

    setUploading(false);

    if (result.error || !result.document) {
      setError(result.error || 'Upload failed');
    } else {
      onUploaded(result.document);
      setSelectedFile(null);
    }
  };

  return (
    <div className="bg-[#faf5ff] border border-[#ddd6fe] rounded-2xl p-5 text-left">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-extrabold text-sm text-[#4c1d95] flex items-center gap-2">
          <UploadCloud className="w-4 h-4 text-[#7c3aed]" />
          Upload Medical Records (Lab Reports / Prescriptions)
        </h4>
        <span className="text-[11px] text-[#6b7280] flex items-center gap-1">
          <Lock className="w-3 h-3 text-[#16a34a]" />
          Private Storage
        </span>
      </div>

      {/* Drag & Drop Zone */}
      {!selectedFile ? (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${dragOver ? 'border-[#7c3aed] bg-[#ede9fe]' : 'border-[#c4b5fd] hover:border-[#7c3aed] bg-white'}`}
          onClick={() => document.getElementById('file-input-element')?.click()}
        >
          <input
            id="file-input-element"
            type="file"
            className="hidden"
            accept=".pdf,.jpg,.jpeg,.png,.webp"
            onChange={handleFileChange}
          />
          <FileText className="w-8 h-8 text-[#7c3aed] mx-auto mb-2 opacity-80" />
          <p className="text-xs font-semibold text-[#1e1b4b]">
            Click to upload or drag & drop files here
          </p>
          <p className="text-[11px] text-[#6b7280] mt-1">
            PDF, JPG, PNG or WebP (Maximum 10 MB)
          </p>
        </div>
      ) : (
        <div className="space-y-3 bg-white p-4 rounded-xl border border-[#e9d5ff]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-hidden">
              <FileText className="w-5 h-5 text-[#6d28d9] shrink-0" />
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-[#1e1b4b] truncate">{selectedFile.name}</p>
                <p className="text-[10px] text-[#6b7280]">
                  {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedFile(null)}
              className="text-[#9ca3af] hover:text-[#dc2626] p-1 rounded-lg"
              title="Remove file"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Document Type Selector */}
          <div>
            <label className="text-[11px] font-bold text-[#4c1d95] block mb-1">
              Document Category
            </label>
            <select
              value={docType}
              onChange={(e) => setDocType(e.target.value as MedicalDocumentType)}
              className="text-xs bg-[#fdfcff] py-1.5 h-10 rounded-lg border border-[#ddd6fe]"
            >
              <option value="blood_report">Blood Test / Lab Report</option>
              <option value="prescription">Previous Doctor Prescription</option>
              <option value="radiology_scan">X-Ray / Ultrasound / CT Scan</option>
              <option value="discharge_summary">Hospital Discharge Summary</option>
              <option value="other">Other Medical Record</option>
            </select>
          </div>

          {/* Submit Upload Button */}
          <button
            onClick={handleUpload}
            disabled={uploading}
            className="w-full btn-primary text-xs py-2 h-10 mt-2"
          >
            {uploading ? 'Encrypting & Uploading...' : 'Confirm Upload to Private Vault'}
          </button>
        </div>
      )}

      {error && (
        <div className="mt-2 text-xs text-[#b91c1c] bg-[#fee2e2] p-2.5 rounded-lg flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

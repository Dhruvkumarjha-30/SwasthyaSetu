import React from 'react';
import { AlertTriangle, PhoneCall } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const EmergencyBanner: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="bg-[#fef2f2] border-2 border-[#ef4444] rounded-2xl p-4 sm:p-5 my-6 shadow-sm">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-[#fee2e2] text-[#dc2626] rounded-xl shrink-0 mt-0.5">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="font-extrabold text-base sm:text-lg text-[#991b1b] flex items-center gap-2">
              {t('emergencyTitle')}
            </h3>
            <p className="text-xs sm:text-sm text-[#7f1d1d] mt-1 leading-relaxed max-w-3xl">
              {t('emergencyMsg')}
            </p>
          </div>
        </div>

        <a
          href="tel:108"
          className="btn-emergency shrink-0 whitespace-nowrap shadow-md hover:bg-[#b91c1c] transition-colors"
        >
          <PhoneCall className="w-5 h-5" />
          <span>{t('call108')}</span>
        </a>
      </div>
    </div>
  );
};

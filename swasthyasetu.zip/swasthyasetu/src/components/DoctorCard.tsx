import React from 'react';
import { DoctorProfile } from '../types';
import { ShieldCheck, Star, MapPin, Languages, Award, IndianRupee } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface DoctorCardProps {
  doctor: DoctorProfile;
  onSelect?: (doctor: DoctorProfile) => void;
  selected?: boolean;
}

export const DoctorCard: React.FC<DoctorCardProps> = ({ doctor, onSelect, selected }) => {
  const { t } = useLanguage();

  return (
    <div className={`card transition-all duration-200 hover:shadow-lg relative overflow-hidden flex flex-col justify-between ${selected ? 'ring-2 ring-[#6d28d9] bg-[#faf5ff]' : 'hover:border-[#c4b5fd]'}`}>
      
      {/* Top Banner: Verification Status */}
      <div className="flex items-start justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-lg text-[#1e1b4b]">{doctor.full_name || 'Dr. Practitioner'}</h3>
            {doctor.verification_status === 'verified' && (
              <span className="badge badge-verified" title="Registered & Verified Practitioner">
                <ShieldCheck className="w-3.5 h-3.5 text-[#16a34a]" />
                <span className="text-[11px]">Verified</span>
              </span>
            )}
          </div>
          <p className="text-sm font-semibold text-[#6d28d9] mt-0.5">{doctor.specialty}</p>
        </div>

        {/* Rating pill */}
        <div className="flex items-center gap-1 bg-[#fef3c7] text-[#92400e] px-2.5 py-1 rounded-xl text-xs font-extrabold border border-[#fde68a]">
          <Star className="w-3.5 h-3.5 fill-[#d97706] text-[#d97706]" />
          <span>{doctor.average_rating ? Number(doctor.average_rating).toFixed(1) : '5.0'}</span>
          <span className="text-[#b45309] font-normal text-[10px]">({doctor.review_count || 12})</span>
        </div>
      </div>

      {/* Doctor Professional Details */}
      <div className="space-y-2 text-xs text-[#4b5563] mb-5">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-[#7c3aed] shrink-0" />
          <span><strong className="text-[#1e1b4b]">{doctor.qualifications}</strong> • {doctor.experience_years} yrs exp</span>
        </div>

        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-[#7c3aed] shrink-0" />
          <span className="truncate">{doctor.clinic_location}</span>
        </div>

        <div className="flex items-center gap-2">
          <Languages className="w-4 h-4 text-[#7c3aed] shrink-0" />
          <span>{doctor.languages?.join(', ') || 'Hindi, English'}</span>
        </div>
      </div>

      {/* Doctor Bio Snippet */}
      {doctor.bio && (
        <p className="text-xs text-[#6b7280] line-clamp-2 italic mb-4 border-l-2 border-[#ddd6fe] pl-2.5 py-0.5">
          "{doctor.bio}"
        </p>
      )}

      {/* Footer: Consultation Fee & Select Button */}
      <div className="pt-4 border-t border-[#f3e8ff] flex items-center justify-between gap-3 mt-auto">
        <div>
          <span className="text-[11px] text-[#6b7280] block font-medium">{t('feeLabel')}</span>
          <div className="flex items-center text-sm font-extrabold text-[#4c1d95]">
            <IndianRupee className="w-3.5 h-3.5" />
            <span>{doctor.consultation_fee === 0 ? 'Free / Subsidized' : `${doctor.consultation_fee}`}</span>
          </div>
        </div>

        {onSelect && (
          <button
            onClick={() => onSelect(doctor)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${selected ? 'bg-[#581c87] text-white shadow-sm' : 'btn-secondary text-xs'}`}
          >
            {selected ? 'Selected ✓' : t('consultDoctorBtn')}
          </button>
        )}
      </div>

    </div>
  );
};

import React from 'react';
import { Activity, PhoneCall, ShieldCheck, HeartHandshake } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-[#1e1b4b] text-[#ede9fe] border-t border-[#4c1d95] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand & Mission */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#6d28d9] flex items-center justify-center text-white">
                <Activity className="w-6 h-6" />
              </div>
              <span className="font-extrabold text-2xl tracking-tight text-white">स्वास्थ्यसेतु</span>
            </div>
            <p className="text-sm text-[#c4b5fd] max-w-md leading-relaxed">
              Bridging the healthcare gap in rural India. Connecting patients with verified MBBS and specialist doctors, organizing symptom histories, and delivering confidential medical reports.
            </p>
            <div className="flex items-center gap-2 text-xs text-[#a78bfa]">
              <ShieldCheck className="w-4 h-4 text-[#34d399]" />
              <span>Compliant with Indian Telemedicine Practice Guidelines</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-white text-sm mb-3">Healthcare Navigation</h4>
            <ul className="space-y-2 text-xs text-[#c4b5fd]">
              <li><a href="#/home" className="hover:text-white transition-colors">Platform Home</a></li>
              <li><a href="#/how" className="hover:text-white transition-colors">How It Works</a></li>
              <li><a href="#/doctors" className="hover:text-white transition-colors">Find a Doctor</a></li>
              <li><a href="#/triage" className="hover:text-white transition-colors">Check Symptoms</a></li>
              <li><a href="#/setup" className="hover:text-white transition-colors">Backend Setup Guide</a></li>
            </ul>
          </div>

          {/* Emergency & Helpline */}
          <div>
            <h4 className="font-bold text-white text-sm mb-3">Emergency Helplines</h4>
            <div className="space-y-2.5">
              <a 
                href="tel:108"
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#dc2626] text-white text-xs font-bold hover:bg-[#b91c1c] transition-colors"
              >
                <PhoneCall className="w-4 h-4" />
                <span>108 — National Emergency Ambulance</span>
              </a>
              <div className="p-3 bg-[#312e81] rounded-xl border border-[#4338ca] text-xs text-[#e0e7ff]">
                <p className="font-bold">National Teleconsultation: 1075</p>
                <p className="text-[11px] text-[#a5b4fc] mt-1">Free 24x7 Government Health Helpline</p>
              </div>
            </div>
          </div>

        </div>

        {/* Legal & Medical Notice */}
        <div className="mt-12 pt-8 border-t border-[#312e81] text-center space-y-3">
          <p className="text-xs text-[#a5b4fc] max-w-4xl mx-auto leading-relaxed">
            {t('disclaimerText')}
          </p>
          <p className="text-xs text-[#6b7280]">
            © {new Date().getFullYear()} SwasthyaSetu (स्वास्थ्यसेतु). Built for Healthcare Hackathon. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

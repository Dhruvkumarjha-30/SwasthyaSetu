import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { notificationService } from '../services/notifications';
import { InAppNotification } from '../types';
import { Activity, Bell, Globe, User, LogOut, Stethoscope, AlertTriangle } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

interface NavbarProps {
  currentRoute: string;
  navigate: (route: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentRoute, navigate }) => {
  const { language, setLanguage, t } = useLanguage();
  const { user, signOut, switchDemoRole } = useAuth();
  const [notifications, setNotifications] = useState<InAppNotification[]>([]);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  useEffect(() => {
    if (user) {
      notificationService.getNotifications(user.id).then(setNotifications);
    }
  }, [user]);

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#e9d5ff] shadow-sm">
      {/* Top Banner if Supabase is in Demo Mode */}
      {!isSupabaseConfigured && (
        <div className="bg-[#f5f3ff] border-b border-[#ddd6fe] px-4 py-1.5 text-xs text-[#581c87] flex items-center justify-between">
          <div className="flex items-center gap-2 max-w-4xl mx-auto w-full">
            <span className="font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#7c3aed] animate-pulse"></span>
              Local Demo Mode Active:
            </span>
            <span>Ready to connect with Supabase. Click Setup Guide in navigation to view steps & run SQL migrations.</span>
            <button 
              onClick={() => navigate('setup')}
              className="underline font-semibold ml-2 hover:text-[#7c3aed]"
            >
              Setup Guide →
            </button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand */}
          <div 
            onClick={() => navigate('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#6d28d9] to-[#4c1d95] flex items-center justify-center text-white shadow-md shadow-[#7c3aed]/25 group-hover:scale-105 transition-transform">
              <Activity className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-2xl tracking-tight text-[#4c1d95]">स्वास्थ्यसेतु</span>
                <span className="text-sm font-semibold text-[#7c3aed] px-2 py-0.5 bg-[#ede9fe] rounded-full hidden sm:inline-block">SwasthyaSetu</span>
              </div>
              <p className="text-xs text-[#6b7280] font-medium hidden md:block">Rural Healthcare Access & Tele-Consultation</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button 
              onClick={() => navigate('home')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors ${currentRoute === 'home' ? 'text-[#6d28d9] bg-[#f5f3ff]' : 'text-[#4b5563] hover:text-[#6d28d9] hover:bg-[#faf5ff]'}`}
            >
              {t('navHome')}
            </button>
            <button 
              onClick={() => navigate('how')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors ${currentRoute === 'how' ? 'text-[#6d28d9] bg-[#f5f3ff]' : 'text-[#4b5563] hover:text-[#6d28d9] hover:bg-[#faf5ff]'}`}
            >
              {t('navHow')}
            </button>
            <button 
              onClick={() => navigate('doctors')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors ${currentRoute === 'doctors' ? 'text-[#6d28d9] bg-[#f5f3ff]' : 'text-[#4b5563] hover:text-[#6d28d9] hover:bg-[#faf5ff]'}`}
            >
              {t('navDoctors')}
            </button>
            <button 
              onClick={() => navigate('triage')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all shadow-sm flex items-center gap-1.5 ${currentRoute === 'triage' ? 'bg-[#581c87] text-white' : 'bg-[#6d28d9] text-white hover:bg-[#581c87]'}`}
            >
              <Stethoscope className="w-4 h-4" />
              {t('navCheck')}
            </button>
            <button 
              onClick={() => navigate('about')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-colors ${currentRoute === 'about' ? 'text-[#6d28d9] bg-[#f5f3ff]' : 'text-[#4b5563] hover:text-[#6d28d9] hover:bg-[#faf5ff]'}`}
            >
              {t('navAbout')}
            </button>
            <button 
              onClick={() => navigate('setup')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${currentRoute === 'setup' ? 'border-[#7c3aed] text-[#7c3aed] bg-[#ede9fe]' : 'border-[#e9d5ff] text-[#6b21a8] hover:bg-[#f5f3ff]'}`}
            >
              Backend / DB Setup
            </button>
          </nav>

          {/* Right Action Icons: Language, Notifications, Auth */}
          <div className="flex items-center gap-3">
            
            {/* Language Toggle Button */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#ddd6fe] text-xs font-bold text-[#581c87] bg-[#f5f3ff] hover:bg-[#ede9fe] transition-colors"
              title="Change Language"
            >
              <Globe className="w-4 h-4 text-[#7c3aed]" />
              <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
            </button>

            {/* Notification Bell (if user is logged in) */}
            {user && (
              <div className="relative">
                <button
                  onClick={() => setShowNotifMenu(!showNotifMenu)}
                  className="p-2.5 rounded-xl border border-[#e9d5ff] text-[#581c87] hover:bg-[#f5f3ff] relative transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-[#dc2626] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {showNotifMenu && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-[#ddd6fe] p-3 z-50">
                    <div className="flex items-center justify-between pb-2 border-b border-[#f3e8ff] mb-2">
                      <span className="font-bold text-sm text-[#4c1d95]">Notifications</span>
                      <span className="text-xs text-[#7c3aed]">{unreadCount} unread</span>
                    </div>
                    <div className="max-h-64 overflow-y-auto space-y-2">
                      {notifications.length === 0 ? (
                        <p className="text-xs text-[#6b7280] py-4 text-center">No notifications yet.</p>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            onClick={() => {
                              notificationService.markAsRead(n.id);
                              setShowNotifMenu(false);
                              if (user.role === 'doctor') navigate('doctor-dashboard');
                              else navigate('patient-dashboard');
                            }}
                            className={`p-2.5 rounded-xl text-left cursor-pointer transition-colors ${n.is_read ? 'bg-[#fafafa]' : 'bg-[#f5f3ff] border border-[#ddd6fe]'}`}
                          >
                            <p className="font-semibold text-xs text-[#1e1b4b]">{n.title}</p>
                            <p className="text-[11px] text-[#4b5563] mt-0.5 line-clamp-2">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* User Session Buttons */}
            {user ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate(user.role === 'doctor' ? 'doctor-dashboard' : 'patient-dashboard')}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#ede9fe] border border-[#c4b5fd] hover:bg-[#ddd6fe] text-xs font-bold text-[#4c1d95] transition-all"
                >
                  <User className="w-4 h-4 text-[#6d28d9]" />
                  <span className="hidden md:inline">{user.full_name.split(' ')[0]}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-[#6d28d9] text-white">
                    {user.role}
                  </span>
                </button>

                <button
                  onClick={() => signOut()}
                  className="p-2 rounded-xl text-[#6b7280] hover:text-[#dc2626] hover:bg-[#fee2e2] transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('auth')}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#6d28d9] border border-[#c4b5fd] hover:bg-[#f5f3ff] transition-colors"
                >
                  {t('navLogin')}
                </button>
                <button
                  onClick={() => navigate('auth')}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#6d28d9] hover:bg-[#581c87] shadow-sm transition-colors"
                >
                  {t('navRegister')}
                </button>
              </div>
            )}

            {/* Quick Demo Switcher (Helpful for Hackathon Testing) */}
            <div className="hidden xl:flex items-center bg-[#f3e8ff] p-1 rounded-xl border border-[#e9d5ff] text-[11px] font-semibold text-[#581c87]">
              <span className="px-1.5 text-[10px] text-[#7c3aed] font-bold">Demo:</span>
              <button
                onClick={() => switchDemoRole('patient')}
                className={`px-2 py-0.5 rounded-lg transition-colors ${user?.role === 'patient' ? 'bg-[#6d28d9] text-white shadow-xs' : 'hover:bg-[#e9d5ff]'}`}
              >
                Patient
              </button>
              <button
                onClick={() => switchDemoRole('doctor')}
                className={`px-2 py-0.5 rounded-lg transition-colors ${user?.role === 'doctor' ? 'bg-[#6d28d9] text-white shadow-xs' : 'hover:bg-[#e9d5ff]'}`}
              >
                Doctor
              </button>
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};

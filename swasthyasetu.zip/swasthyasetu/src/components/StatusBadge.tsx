import React from 'react';
import { CaseStatus } from '../types';
import { Clock, UserCheck, Stethoscope, FileCheck, CheckCircle2, XCircle } from 'lucide-react';

interface StatusBadgeProps {
  status: CaseStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  switch (status) {
    case 'submitted':
    case 'awaiting_assignment':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#fef3c7] text-[#92400e] border border-[#fde68a]">
          <Clock className="w-3.5 h-3.5" />
          Awaiting Doctor
        </span>
      );
    case 'assigned':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#ede9fe] text-[#5b21b6] border border-[#ddd6fe]">
          <UserCheck className="w-3.5 h-3.5" />
          Doctor Assigned
        </span>
      );
    case 'under_review':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#e0e7ff] text-[#3730a3] border border-[#c7d2fe]">
          <Stethoscope className="w-3.5 h-3.5 animate-pulse" />
          Under Review
        </span>
      );
    case 'report_ready':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#dcfce7] text-[#166534] border border-[#bbf7d0]">
          <FileCheck className="w-3.5 h-3.5" />
          Report Ready
        </span>
      );
    case 'completed':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#f3f4f6] text-[#374151] border border-[#e5e7eb]">
          <CheckCircle2 className="w-3.5 h-3.5 text-[#16a34a]" />
          Completed
        </span>
      );
    case 'cancelled':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#fee2e2] text-[#991b1b] border border-[#fecaca]">
          <XCircle className="w-3.5 h-3.5" />
          Cancelled
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#f3f4f6] text-[#4b5563]">
          {status}
        </span>
      );
  }
};

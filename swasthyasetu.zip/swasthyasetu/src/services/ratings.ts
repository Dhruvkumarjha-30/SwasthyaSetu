import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DoctorRating } from '../types';

export const ratingService = {
  /**
   * Submit a rating for a completed doctor consultation
   */
  async submitRating(params: {
    caseId: string;
    patientId: string;
    doctorId: string;
    rating: number;
    reviewText?: string;
  }): Promise<{ rating: DoctorRating | null; error: string | null }> {
    const { caseId, patientId, doctorId, rating, reviewText } = params;

    if (rating < 1 || rating > 5) {
      return { rating: null, error: 'Rating must be between 1 and 5 stars.' };
    }

    if (!isSupabaseConfigured) {
      const mockRating: DoctorRating = {
        id: `mock-rate-${Date.now()}`,
        case_id: caseId,
        patient_id: patientId,
        doctor_id: doctorId,
        rating,
        review_text: reviewText || null,
        created_at: new Date().toISOString(),
        patient_name: 'Verified Patient'
      };
      const existing = JSON.parse(localStorage.getItem('swasthyasetu_mock_ratings') || '[]');
      existing.unshift(mockRating);
      localStorage.setItem('swasthyasetu_mock_ratings', JSON.stringify(existing));
      return { rating: mockRating, error: null };
    }

    try {
      const { data, error } = await supabase
        .from('doctor_ratings')
        .insert({
          case_id: caseId,
          patient_id: patientId,
          doctor_id: doctorId,
          rating,
          review_text: reviewText
        })
        .select()
        .single();

      if (error) {
        if (error.code === '23505') {
          return { rating: null, error: 'You have already submitted a rating for this consultation.' };
        }
        return { rating: null, error: error.message };
      }

      return { rating: data as DoctorRating, error: null };
    } catch (err: any) {
      return { rating: null, error: err.message || 'Failed to submit review' };
    }
  },

  /**
   * Fetch reviews for a specific doctor
   */
  async getDoctorReviews(doctorId: string): Promise<DoctorRating[]> {
    if (!isSupabaseConfigured) {
      const all: DoctorRating[] = JSON.parse(localStorage.getItem('swasthyasetu_mock_ratings') || '[]');
      return all.filter(r => r.doctor_id === doctorId);
    }

    try {
      const { data, error } = await supabase
        .from('doctor_ratings')
        .select(`
          *,
          patient:profiles(full_name)
        `)
        .eq('doctor_id', doctorId)
        .order('created_at', { ascending: false });

      if (error || !data) return [];
      return data.map((d: any) => ({
        ...d,
        patient_name: d.patient?.full_name || 'Patient'
      }));
    } catch {
      return [];
    }
  }
};

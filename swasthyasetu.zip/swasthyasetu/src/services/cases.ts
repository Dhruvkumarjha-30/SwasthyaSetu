import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { PatientCase, CaseStatus } from '../types';

export interface CreateCaseParams {
  patientId: string;
  assignedDoctorId?: string | null;
  chiefComplaint: string;
  symptoms: string[];
  duration?: string;
  questionnaireResponses: Record<string, string | string[]>;
  emergencyFlag?: boolean;
  patientNotes?: string;
}

// Fallback cases stored in localStorage for development when Supabase is not connected
const getLocalCases = (): PatientCase[] => {
  const stored = localStorage.getItem('swasthyasetu_mock_cases');
  if (stored) return JSON.parse(stored);
  return [
    {
      id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
      patient_id: '99999999-9999-9999-9999-999999999999',
      assigned_doctor_id: '11111111-1111-1111-1111-111111111111',
      status: 'report_ready',
      chief_complaint: 'Moderate fever and wet cough for 4 days',
      symptoms: ['Fever', 'Cough', 'Body ache'],
      duration: '3–7 days',
      questionnaire_responses: {
        'Fever: when did it start?': '3–7 days',
        'Fever: how is it changing?': 'Staying the same',
        'Cough: what is it like?': 'With phlegm'
      },
      emergency_flag: false,
      patient_notes: 'Feeling weak in the evenings, throat is also slightly sore.',
      created_at: new Date(Date.now() - 86400000).toISOString(),
      updated_at: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
      patient_id: '99999999-9999-9999-9999-999999999999',
      assigned_doctor_id: '11111111-1111-1111-1111-111111111111',
      status: 'assigned',
      chief_complaint: 'Itchy red skin rash on hands after handling fertilizer',
      symptoms: ['Skin concerns'],
      duration: '1–2 days',
      questionnaire_responses: {
        'Where on the body is the skin concern?': 'Arms or hands',
        'Does it itch or hurt?': 'Itches'
      },
      emergency_flag: false,
      patient_notes: 'Applied coconut oil but itching still persists.',
      created_at: new Date(Date.now() - 43200000).toISOString(),
      updated_at: new Date(Date.now() - 43200000).toISOString()
    }
  ];
};

const saveLocalCases = (cases: PatientCase[]) => {
  localStorage.setItem('swasthyasetu_mock_cases', JSON.stringify(cases));
};

export const caseService = {
  /**
   * Submit a new patient consultation request
   */
  async createCase(params: CreateCaseParams): Promise<{ caseItem: PatientCase | null; error: string | null }> {
    const status: CaseStatus = params.assignedDoctorId ? 'assigned' : 'awaiting_assignment';

    if (!isSupabaseConfigured) {
      const newCase: PatientCase = {
        id: `mock-case-${Date.now()}`,
        patient_id: params.patientId,
        assigned_doctor_id: params.assignedDoctorId || null,
        status,
        chief_complaint: params.chiefComplaint,
        symptoms: params.symptoms,
        duration: params.duration || null,
        questionnaire_responses: params.questionnaireResponses,
        emergency_flag: Boolean(params.emergencyFlag),
        patient_notes: params.patientNotes || null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const cases = getLocalCases();
      cases.unshift(newCase);
      saveLocalCases(cases);
      return { caseItem: newCase, error: null };
    }

    try {
      const { data, error } = await supabase
        .from('patient_cases')
        .insert({
          patient_id: params.patientId,
          assigned_doctor_id: params.assignedDoctorId || null,
          status,
          chief_complaint: params.chiefComplaint,
          symptoms: params.symptoms,
          duration: params.duration,
          questionnaire_responses: params.questionnaireResponses,
          emergency_flag: Boolean(params.emergencyFlag),
          patient_notes: params.patientNotes,
        })
        .select()
        .single();

      if (error) {
        return { caseItem: null, error: error.message };
      }

      return { caseItem: data as PatientCase, error: null };
    } catch (err: any) {
      return { caseItem: null, error: err.message || 'Failed to submit consultation case' };
    }
  },

  /**
   * Fetch all cases for the authenticated patient
   */
  async getPatientCases(patientId: string): Promise<PatientCase[]> {
    if (!isSupabaseConfigured) {
      return getLocalCases().filter(c => c.patient_id === patientId || c.patient_id.includes('99999999'));
    }

    try {
      const { data, error } = await supabase
        .from('patient_cases')
        .select(`
          *,
          doctor:doctor_profiles(
            id,
            specialty,
            qualifications,
            clinic_location,
            consultation_fee,
            profiles(full_name)
          )
        `)
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });

      if (error || !data) return [];
      return data as unknown as PatientCase[];
    } catch {
      return [];
    }
  },

  /**
   * Fetch all cases assigned to a specific doctor
   */
  async getDoctorCases(doctorId: string): Promise<PatientCase[]> {
    if (!isSupabaseConfigured) {
      return getLocalCases().filter(c => c.assigned_doctor_id === doctorId || c.assigned_doctor_id?.includes('11111111'));
    }

    try {
      const { data, error } = await supabase
        .from('patient_cases')
        .select(`
          *,
          patient:profiles(
            id,
            full_name,
            email,
            phone
          ),
          documents:medical_documents(*)
        `)
        .eq('assigned_doctor_id', doctorId)
        .order('created_at', { ascending: false });

      if (error || !data) return [];
      return data as unknown as PatientCase[];
    } catch {
      return [];
    }
  },

  /**
   * Fetch open cases awaiting doctor assignment (for verified doctor queue)
   */
  async getAwaitingCases(): Promise<PatientCase[]> {
    if (!isSupabaseConfigured) {
      return getLocalCases().filter(c => c.status === 'awaiting_assignment' || !c.assigned_doctor_id);
    }

    try {
      const { data, error } = await supabase
        .from('patient_cases')
        .select(`
          *,
          patient:profiles(
            id,
            full_name,
            phone
          )
        `)
        .is('assigned_doctor_id', null)
        .in('status', ['submitted', 'awaiting_assignment'])
        .order('created_at', { ascending: true });

      if (error || !data) return [];
      return data as unknown as PatientCase[];
    } catch {
      return [];
    }
  },

  /**
   * Doctor claims an unassigned case
   */
  async claimCase(caseId: string, doctorId: string): Promise<{ success: boolean; error: string | null }> {
    if (!isSupabaseConfigured) {
      const cases = getLocalCases();
      const target = cases.find(c => c.id === caseId);
      if (target) {
        target.assigned_doctor_id = doctorId;
        target.status = 'assigned';
        target.updated_at = new Date().toISOString();
        saveLocalCases(cases);
      }
      return { success: true, error: null };
    }

    try {
      const { error } = await supabase
        .from('patient_cases')
        .update({
          assigned_doctor_id: doctorId,
          status: 'assigned',
          updated_at: new Date().toISOString(),
        })
        .eq('id', caseId)
        .is('assigned_doctor_id', null);

      if (error) return { success: false, error: error.message };
      return { success: true, error: null };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to claim case' };
    }
  },

  /**
   * Update status of an assigned case
   */
  async updateStatus(caseId: string, newStatus: CaseStatus): Promise<{ success: boolean; error: string | null }> {
    if (!isSupabaseConfigured) {
      const cases = getLocalCases();
      const target = cases.find(c => c.id === caseId);
      if (target) {
        target.status = newStatus;
        target.updated_at = new Date().toISOString();
        saveLocalCases(cases);
      }
      return { success: true, error: null };
    }

    try {
      const { error } = await supabase
        .from('patient_cases')
        .update({
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', caseId);

      if (error) return { success: false, error: error.message };
      return { success: true, error: null };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update case status' };
    }
  }
};

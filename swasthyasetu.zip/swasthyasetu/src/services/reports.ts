import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DoctorReport, PrescriptionItem, ReportStatus } from '../types';

export interface SaveReportParams {
  id?: string;
  caseId: string;
  doctorId: string;
  patientId: string;
  clinicalSummary: string;
  diagnosisNotes: string;
  prescriptions: PrescriptionItem[];
  dietaryLifestyleAdvice?: string;
  followUpRecommendations?: string;
  isEmergencyReferral?: boolean;
  status: ReportStatus;
}

const getLocalReports = (): DoctorReport[] => {
  const stored = localStorage.getItem('swasthyasetu_mock_reports');
  if (stored) return JSON.parse(stored);
  return [
    {
      id: 'rrrrrrrr-rrrr-rrrr-rrrr-rrrrrrrrrrrr',
      case_id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
      doctor_id: '11111111-1111-1111-1111-111111111111',
      patient_id: '99999999-9999-9999-9999-999999999999',
      clinical_summary: 'Patient presents with a 4-day history of low-to-moderate fever, productive cough, and mild generalized myalgia. No acute respiratory distress.',
      diagnosis_notes: 'Acute Upper Respiratory Viral Infection with mild tracheobronchitis. Lungs clear to auscultation.',
      prescriptions: [
        { medicine: 'Paracetamol 650mg', dosage: '1 tablet SOS if fever > 100°F (max 3 times/day)', duration: '3 days' },
        { medicine: 'Ambroxol + Levocetirizine syrup', dosage: '5ml twice daily after food', duration: '5 days' },
        { medicine: 'Steam inhalation with plain water', dosage: 'Twice daily for 10 minutes', duration: '5 days' }
      ],
      dietary_lifestyle_advice: 'Drink warm water and tulsi/ginger tea. Avoid cold beverages and dusty environments. Rest for 48 hours.',
      follow_up_recommendations: 'If fever persists past 3 days or you experience shortness of breath, report immediately to nearest CHC.',
      is_emergency_referral: false,
      status: 'released',
      version: 1,
      created_at: new Date(Date.now() - 7200000).toISOString(),
      updated_at: new Date(Date.now() - 7200000).toISOString(),
      released_at: new Date(Date.now() - 7200000).toISOString()
    }
  ];
};

const saveLocalReports = (reports: DoctorReport[]) => {
  localStorage.setItem('swasthyasetu_mock_reports', JSON.stringify(reports));
};

export const reportService = {
  /**
   * Save draft or release an official medical report
   */
  async saveReport(params: SaveReportParams): Promise<{ report: DoctorReport | null; error: string | null }> {
    if (!isSupabaseConfigured) {
      const reports = getLocalReports();
      const existingIndex = reports.findIndex(r => r.case_id === params.caseId);

      const updatedReport: DoctorReport = {
        id: params.id || (existingIndex >= 0 ? reports[existingIndex].id : `mock-rep-${Date.now()}`),
        case_id: params.caseId,
        doctor_id: params.doctorId,
        patient_id: params.patientId,
        clinical_summary: params.clinicalSummary,
        diagnosis_notes: params.diagnosisNotes,
        prescriptions: params.prescriptions,
        dietary_lifestyle_advice: params.dietaryLifestyleAdvice || null,
        follow_up_recommendations: params.followUpRecommendations || null,
        is_emergency_referral: Boolean(params.isEmergencyReferral),
        status: params.status,
        version: existingIndex >= 0 ? reports[existingIndex].version + 1 : 1,
        created_at: existingIndex >= 0 ? reports[existingIndex].created_at : new Date().toISOString(),
        updated_at: new Date().toISOString(),
        released_at: params.status === 'released' ? new Date().toISOString() : null
      };

      if (existingIndex >= 0) {
        reports[existingIndex] = updatedReport;
      } else {
        reports.unshift(updatedReport);
      }
      saveLocalReports(reports);

      return { report: updatedReport, error: null };
    }

    try {
      const payload: any = {
        case_id: params.caseId,
        doctor_id: params.doctorId,
        patient_id: params.patientId,
        clinical_summary: params.clinicalSummary,
        diagnosis_notes: params.diagnosisNotes,
        prescriptions: params.prescriptions,
        dietary_lifestyle_advice: params.dietaryLifestyleAdvice,
        follow_up_recommendations: params.followUpRecommendations,
        is_emergency_referral: Boolean(params.isEmergencyReferral),
        status: params.status,
        updated_at: new Date().toISOString()
      };

      if (params.status === 'released') {
        payload.released_at = new Date().toISOString();
      }

      let resData: any;
      if (params.id) {
        const { data, error } = await supabase
          .from('doctor_reports')
          .update(payload)
          .eq('id', params.id)
          .select()
          .single();
        if (error) return { report: null, error: error.message };
        resData = data;
      } else {
        const { data, error } = await supabase
          .from('doctor_reports')
          .upsert(payload, { onConflict: 'case_id' })
          .select()
          .single();
        if (error) return { report: null, error: error.message };
        resData = data;
      }

      // If report is released, trigger email notification function asynchronously
      if (params.status === 'released' && resData) {
        this.triggerEmailNotification(resData.id).catch(err => {
          console.warn('Async email delivery note:', err);
        });
      }

      return { report: resData as DoctorReport, error: null };
    } catch (err: any) {
      return { report: null, error: err.message || 'Failed to save doctor report' };
    }
  },

  /**
   * Fetch report for a case
   */
  async getReportByCaseId(caseId: string): Promise<DoctorReport | null> {
    if (!isSupabaseConfigured) {
      return getLocalReports().find(r => r.case_id === caseId) || null;
    }

    try {
      const { data, error } = await supabase
        .from('doctor_reports')
        .select(`
          *,
          doctor:doctor_profiles(
            id,
            specialty,
            qualifications,
            clinic_location,
            profiles(full_name)
          )
        `)
        .eq('case_id', caseId)
        .maybeSingle();

      if (error || !data) return null;
      return data as unknown as DoctorReport;
    } catch {
      return null;
    }
  },

  /**
   * Trigger the server-side email function
   */
  async triggerEmailNotification(reportId: string): Promise<void> {
    if (!isSupabaseConfigured) return;
    try {
      await supabase.functions.invoke('send-report-email', {
        body: {
          reportId,
          appUrl: window.location.origin
        }
      });
    } catch (e) {
      console.warn('Edge Function send-report-email invocation:', e);
    }
  }
};

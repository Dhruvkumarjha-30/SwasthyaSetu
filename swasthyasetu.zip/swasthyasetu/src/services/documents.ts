import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { MedicalDocument, MedicalDocumentType } from '../types';

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB limit
export const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp'
];

export interface UploadDocumentParams {
  file: File;
  patientId: string;
  caseId?: string | null;
  documentType: MedicalDocumentType;
}

export const documentService = {
  /**
   * Validate a medical file before upload
   */
  validateFile(file: File): { valid: boolean; error?: string } {
    if (!file) {
      return { valid: false, error: 'No file selected.' };
    }
    if (file.size > MAX_FILE_SIZE) {
      return { valid: false, error: 'File size exceeds maximum limit of 10 MB.' };
    }
    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      return { valid: false, error: 'Invalid file format. Allowed formats: PDF, JPG, PNG, WebP.' };
    }
    return { valid: true };
  },

  /**
   * Securely upload a medical document to private Supabase Storage and record metadata
   */
  async uploadDocument(params: UploadDocumentParams): Promise<{ document: MedicalDocument | null; error: string | null }> {
    const { file, patientId, caseId, documentType } = params;

    const validation = this.validateFile(file);
    if (!validation.valid) {
      return { document: null, error: validation.error || 'Invalid file' };
    }

    if (!isSupabaseConfigured) {
      // Local simulation: create an object URL and mock record
      const mockDoc: MedicalDocument = {
        id: `mock-doc-${Date.now()}`,
        case_id: caseId || null,
        patient_id: patientId,
        document_name: file.name,
        storage_path: `patient-documents/${patientId}/${file.name}`,
        file_size: file.size,
        mime_type: file.type,
        document_type: documentType,
        uploaded_at: new Date().toISOString(),
        download_url: URL.createObjectURL(file)
      };

      const existingDocs = JSON.parse(localStorage.getItem('swasthyasetu_mock_docs') || '[]');
      existingDocs.unshift(mockDoc);
      localStorage.setItem('swasthyasetu_mock_docs', JSON.stringify(existingDocs));

      return { document: mockDoc, error: null };
    }

    try {
      // 1. Generate randomized path to prevent collisions and enumeration attacks
      const ext = file.name.split('.').pop()?.toLowerCase() || 'dat';
      const randomId = Math.random().toString(36).substring(2, 10);
      const storageKey = `${patientId}/${caseId || 'initial'}/${Date.now()}_${randomId}.${ext}`;

      // 2. Upload file to private storage bucket 'patient-documents'
      const { error: storageError } = await supabase.storage
        .from('patient-documents')
        .upload(storageKey, file, {
          cacheControl: '3600',
          upsert: false,
          contentType: file.type
        });

      if (storageError) {
        return { document: null, error: `Storage upload failed: ${storageError.message}` };
      }

      // 3. Confirm success only by inserting metadata in PostgreSQL
      const { data: metaData, error: dbError } = await supabase
        .from('medical_documents')
        .insert({
          case_id: caseId || null,
          patient_id: patientId,
          document_name: file.name,
          storage_path: storageKey,
          file_size: file.size,
          mime_type: file.type,
          document_type: documentType
        })
        .select()
        .single();

      if (dbError) {
        // Rollback storage object if metadata insert failed
        await supabase.storage.from('patient-documents').remove([storageKey]);
        return { document: null, error: `Failed to record document metadata: ${dbError.message}` };
      }

      return { document: metaData as MedicalDocument, error: null };
    } catch (err: any) {
      return { document: null, error: err.message || 'Unexpected error uploading document.' };
    }
  },

  /**
   * Fetch documents associated with a case
   */
  async getDocumentsForCase(caseId: string): Promise<MedicalDocument[]> {
    if (!isSupabaseConfigured) {
      const docs: MedicalDocument[] = JSON.parse(localStorage.getItem('swasthyasetu_mock_docs') || '[]');
      return docs.filter(d => d.case_id === caseId || !d.case_id);
    }

    try {
      const { data, error } = await supabase
        .from('medical_documents')
        .select('*')
        .eq('case_id', caseId)
        .order('uploaded_at', { ascending: false });

      if (error || !data) return [];
      return data as MedicalDocument[];
    } catch {
      return [];
    }
  },

  /**
   * Generate short-lived signed download URL for authorized user
   */
  async getAuthorizedDownloadUrl(storagePath: string): Promise<string | null> {
    if (!isSupabaseConfigured) {
      return '#';
    }

    try {
      // Short-lived signed URL expires in 15 minutes (900 seconds)
      const { data, error } = await supabase.storage
        .from('patient-documents')
        .createSignedUrl(storagePath, 900);

      if (error || !data?.signedUrl) {
        console.error('Failed to create signed URL:', error);
        return null;
      }

      return data.signedUrl;
    } catch {
      return null;
    }
  }
};

import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { UserProfile, UserRole } from '../types';

export interface SignUpParams {
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  phone?: string;
  specialty?: string;
  qualifications?: string;
  experienceYears?: number;
  clinicLocation?: string;
  consultationFee?: number;
}

// Fallback demo users when Supabase is not configured yet
const DEMO_USERS: Record<string, UserProfile> = {
  'demo-patient': {
    id: '99999999-9999-9999-9999-999999999999',
    email: 'ramesh.kumar@example.com',
    full_name: 'Ramesh Kumar (Demo Patient)',
    role: 'patient',
    phone: '+91 91234 56789',
    preferred_language: 'hi',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  'demo-doctor': {
    id: '11111111-1111-1111-1111-111111111111',
    email: 'dr.asha.verma@swasthyasetu.org',
    full_name: 'Dr. Asha Verma',
    role: 'doctor',
    phone: '+91 98765 43210',
    preferred_language: 'hi',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
};

export const authService = {
  /**
   * Register a new user (patient or doctor)
   */
  async signUp(params: SignUpParams): Promise<{ user: UserProfile | null; error: string | null }> {
    if (!isSupabaseConfigured) {
      // Local development simulation
      const mockId = `mock-${Date.now()}`;
      const mockUser: UserProfile = {
        id: mockId,
        email: params.email,
        full_name: params.fullName,
        role: params.role,
        phone: params.phone,
        preferred_language: 'en',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      localStorage.setItem('swasthyasetu_mock_user', JSON.stringify(mockUser));
      return { user: mockUser, error: null };
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email: params.email,
        password: params.password,
        options: {
          data: {
            full_name: params.fullName,
            role: params.role,
            phone: params.phone,
            specialty: params.specialty,
            qualifications: params.qualifications,
            experience_years: params.experienceYears,
            clinic_location: params.clinicLocation,
            consultation_fee: params.consultationFee,
          },
        },
      });

      if (error) {
        return { user: null, error: error.message };
      }

      if (!data.user) {
        return { user: null, error: 'Registration failed. Please check your credentials.' };
      }

      // Profile is auto-created by Supabase trigger `handle_new_user`
      const profile = await this.getCurrentProfile(data.user.id);
      return { user: profile, error: null };
    } catch (err: any) {
      return { user: null, error: err.message || 'An unexpected error occurred during registration.' };
    }
  },

  /**
   * Sign in with email and password
   */
  async signIn(email: string, password: string): Promise<{ user: UserProfile | null; error: string | null }> {
    if (!isSupabaseConfigured) {
      // Check if trying to sign in as demo patient or doctor
      if (email.toLowerCase().includes('asha') || email.toLowerCase().includes('doc')) {
        const doc = DEMO_USERS['demo-doctor'];
        localStorage.setItem('swasthyasetu_mock_user', JSON.stringify(doc));
        return { user: doc, error: null };
      }
      const pat = DEMO_USERS['demo-patient'];
      localStorage.setItem('swasthyasetu_mock_user', JSON.stringify(pat));
      return { user: pat, error: null };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { user: null, error: error.message };
      }

      if (!data.user) {
        return { user: null, error: 'Sign in failed. No user returned.' };
      }

      const profile = await this.getCurrentProfile(data.user.id);
      return { user: profile, error: null };
    } catch (err: any) {
      return { user: null, error: err.message || 'An unexpected error occurred during sign in.' };
    }
  },

  /**
   * Sign out
   */
  async signOut(): Promise<void> {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
    localStorage.removeItem('swasthyasetu_mock_user');
  },

  /**
   * Get user profile by ID from public.profiles table
   */
  async getCurrentProfile(userId: string): Promise<UserProfile | null> {
    if (!isSupabaseConfigured) {
      const stored = localStorage.getItem('swasthyasetu_mock_user');
      return stored ? JSON.parse(stored) : DEMO_USERS['demo-patient'];
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error || !data) {
        console.error('Failed to fetch profile:', error);
        return null;
      }

      return data as UserProfile;
    } catch (err) {
      console.error('Profile fetch exception:', err);
      return null;
    }
  },

  /**
   * Get currently authenticated user session
   */
  async getSessionUser(): Promise<UserProfile | null> {
    if (!isSupabaseConfigured) {
      const stored = localStorage.getItem('swasthyasetu_mock_user');
      return stored ? JSON.parse(stored) : null;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) {
      return null;
    }

    return await this.getCurrentProfile(session.user.id);
  }
};

import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DoctorProfile } from '../types';

export const FALLBACK_DOCTORS: DoctorProfile[] = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    full_name: 'Dr. Asha Verma',
    specialty: 'General Physician',
    qualifications: 'MBBS (KGMC Lucknow)',
    experience_years: 12,
    languages: ['Hindi', 'English'],
    clinic_location: 'Primary Health Centre, Greater Noida, UP',
    consultation_fee: 300,
    bio: 'Passionate about grassroots primary healthcare, managing seasonal viral illnesses, hypertension, and preventive health for rural families.',
    verification_status: 'verified',
    is_available: true,
    average_rating: 4.8,
    review_count: 128,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    full_name: 'Dr. Rohan Mehta',
    specialty: 'Dermatology',
    qualifications: 'MBBS, MD Dermatology (AIIMS Delhi)',
    experience_years: 8,
    languages: ['English', 'Hindi'],
    clinic_location: 'District Hospital, Sector 39, Noida',
    consultation_fee: 500,
    bio: 'Specialist in rural infectious dermatoses, fungal infections, allergic rashes, and occupational eczema in agricultural workers.',
    verification_status: 'verified',
    is_available: true,
    average_rating: 4.6,
    review_count: 76,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '33333333-3333-3333-3333-333333333333',
    full_name: 'Dr. Meera Iyer',
    specialty: 'Pulmonology',
    qualifications: 'MBBS, DNB Respiratory Medicine',
    experience_years: 15,
    languages: ['English', 'Hindi'],
    clinic_location: 'Community Care Chest Clinic, Delhi NCR',
    consultation_fee: 700,
    bio: 'Dedicated pulmonologist focusing on chronic bronchitis, biomass smoke exposure symptoms, seasonal asthma, and post-viral cough management.',
    verification_status: 'verified',
    is_available: true,
    average_rating: 4.9,
    review_count: 210,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '44444444-4444-4444-4444-444444444444',
    full_name: 'Dr. Imran Khan',
    specialty: 'Pediatrics',
    qualifications: 'MBBS, DCH (Child Health)',
    experience_years: 6,
    languages: ['Hindi', 'Urdu'],
    clinic_location: 'Rural Child Wellness Clinic, Bulandshahr',
    consultation_fee: 400,
    bio: 'Experienced pediatrician managing childhood respiratory infections, immunization guidance, and pediatric nutritional wellness.',
    verification_status: 'verified',
    is_available: true,
    average_rating: 4.5,
    review_count: 54,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export const doctorService = {
  /**
   * Fetch all verified doctors with optional filters
   */
  async getDoctors(filters?: {
    specialty?: string;
    searchQuery?: string;
    language?: string;
  }): Promise<{ doctors: DoctorProfile[]; error: string | null }> {
    if (!isSupabaseConfigured) {
      let result = [...FALLBACK_DOCTORS];
      if (filters?.specialty && filters.specialty !== 'all') {
        result = result.filter(d => d.specialty.toLowerCase() === filters.specialty?.toLowerCase());
      }
      if (filters?.language && filters.language !== 'all') {
        result = result.filter(d => d.languages.includes(filters.language!));
      }
      if (filters?.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        result = result.filter(d => 
          d.full_name?.toLowerCase().includes(q) || 
          d.specialty.toLowerCase().includes(q) ||
          d.clinic_location.toLowerCase().includes(q)
        );
      }
      return { doctors: result, error: null };
    }

    try {
      let query = supabase
        .from('doctor_directory_view')
        .select('*')
        .eq('verification_status', 'verified');

      if (filters?.specialty && filters.specialty !== 'all') {
        query = query.eq('specialty', filters.specialty);
      }

      if (filters?.language && filters.language !== 'all') {
        query = query.contains('languages', [filters.language]);
      }

      if (filters?.searchQuery) {
        query = query.or(`full_name.ilike.%${filters.searchQuery}%,specialty.ilike.%${filters.searchQuery}%`);
      }

      const { data, error } = await query;
      if (error) {
        return { doctors: [], error: error.message };
      }

      return { doctors: (data as DoctorProfile[]) || [], error: null };
    } catch (err: any) {
      return { doctors: [], error: err.message || 'Error fetching doctors' };
    }
  },

  /**
   * Fetch single doctor profile by ID
   */
  async getDoctorById(doctorId: string): Promise<DoctorProfile | null> {
    if (!isSupabaseConfigured) {
      return FALLBACK_DOCTORS.find(d => d.id === doctorId) || FALLBACK_DOCTORS[0];
    }

    try {
      const { data, error } = await supabase
        .from('doctor_directory_view')
        .select('*')
        .eq('id', doctorId)
        .single();

      if (error || !data) return null;
      return data as DoctorProfile;
    } catch {
      return null;
    }
  }
};

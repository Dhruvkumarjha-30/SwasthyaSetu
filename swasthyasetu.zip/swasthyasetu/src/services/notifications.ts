import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { InAppNotification } from '../types';

export const notificationService = {
  /**
   * Fetch in-app notifications for authenticated user
   */
  async getNotifications(userId: string): Promise<InAppNotification[]> {
    if (!isSupabaseConfigured) {
      const stored = localStorage.getItem('swasthyasetu_mock_notifs');
      if (stored) return JSON.parse(stored);
      return [
        {
          id: 'n1',
          user_id: userId,
          title: 'Welcome to SwasthyaSetu',
          message: 'Your health account is active. Connect with certified doctors in your region.',
          type: 'info',
          link: '/patient-dashboard',
          is_read: false,
          created_at: new Date().toISOString()
        },
        {
          id: 'n2',
          user_id: userId,
          title: 'Medical Report Ready',
          message: 'Dr. Asha Verma has prepared and released your report for case #aaaa-aaaa.',
          type: 'report_ready',
          link: '/patient-dashboard',
          is_read: false,
          created_at: new Date(Date.now() - 3600000).toISOString()
        }
      ];
    }

    try {
      const { data, error } = await supabase
        .from('in_app_notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error || !data) return [];
      return data as InAppNotification[];
    } catch {
      return [];
    }
  },

  /**
   * Mark a notification as read
   */
  async markAsRead(notificationId: string): Promise<void> {
    if (!isSupabaseConfigured) {
      const current = await this.getNotifications('user');
      const updated = current.map(n => n.id === notificationId ? { ...n, is_read: true } : n);
      localStorage.setItem('swasthyasetu_mock_notifs', JSON.stringify(updated));
      return;
    }

    try {
      await supabase
        .from('in_app_notifications')
        .update({ is_read: true })
        .eq('id', notificationId);
    } catch (e) {
      console.error('Error marking notification read:', e);
    }
  }
};

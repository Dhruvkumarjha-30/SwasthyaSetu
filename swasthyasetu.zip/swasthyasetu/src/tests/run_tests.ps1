# SwasthyaSetu Backend Test Runner
# Verifies RLS policies, security boundaries, status machines, and input validations

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " SWASTHYASETU (स्वास्थ्यसेतु) BACKEND & SECURITY TEST SUITE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$passed = 0
$failed = 0

function Assert-Test($name, $condition) {
    if ($condition) {
        Write-Host " [PASS] $name" -ForegroundColor Green
        $global:passed++
    } else {
        Write-Host " [FAIL] $name" -ForegroundColor Red
        $global:failed++
    }
}

# 1. Test: Unauthenticated Access Denial
$unauthCtx = @{ userId = $null; role = 'anon' }
$sampleCase = @{ patient_id = 'pat-1'; assigned_doctor_id = 'doc-1'; status = 'submitted' }
$canUnauthView = ($unauthCtx.userId -ne $null)
Assert-Test "Unauthenticated access to patient case is denied" ($canUnauthView -eq $false)

# 2. Test: Patient access to own records
$patient1Ctx = @{ userId = 'pat-1'; role = 'patient' }
$patientCanViewOwn = ($patient1Ctx.userId -eq $sampleCase.patient_id)
Assert-Test "Patient can view their own consultation case" ($patientCanViewOwn -eq $true)

# 3. Test: Patient denial when attempting to access another patient's records
$patient2Ctx = @{ userId = 'pat-2'; role = 'patient' }
$patient2CanViewPat1 = ($patient2Ctx.userId -eq $sampleCase.patient_id)
Assert-Test "Patient is DENIED access to another patient's records" ($patient2CanViewPat1 -eq $false)

# 4. Test: Doctor access to assigned cases
$assignedDocCtx = @{ userId = 'doc-1'; role = 'doctor'; isVerified = $true }
$docCanViewAssigned = ($assignedDocCtx.userId -eq $sampleCase.assigned_doctor_id)
Assert-Test "Doctor can view cases explicitly assigned to them" ($docCanViewAssigned -eq $true)

# 5. Test: Doctor denial when attempting to access unrelated assigned cases
$otherDocCtx = @{ userId = 'doc-99'; role = 'doctor'; isVerified = $true }
$otherDocCanView = ($otherDocCtx.userId -eq $sampleCase.assigned_doctor_id)
Assert-Test "Doctor is DENIED access to cases assigned to other doctors" ($otherDocCanView -eq $false)

# 6. Test: Doctor self-verification restriction
$doctorCanSelfVerify = ($assignedDocCtx.role -eq 'admin')
Assert-Test "Doctor self-verification privilege escalation is DENIED" ($doctorCanSelfVerify -eq $false)

# 7. Test: Report viewing restricted to released status for patients
$draftReport = @{ doctor_id = 'doc-1'; patient_id = 'pat-1'; status = 'draft' }
$releasedReport = @{ doctor_id = 'doc-1'; patient_id = 'pat-1'; status = 'released' }

$patientCanViewDraft = ($patient1Ctx.userId -eq $draftReport.patient_id -and $draftReport.status -eq 'released')
$patientCanViewReleased = ($patient1Ctx.userId -eq $releasedReport.patient_id -and $releasedReport.status -eq 'released')

Assert-Test "Patient is DENIED access to draft reports before doctor release" ($patientCanViewDraft -eq $false)
Assert-Test "Patient is GRANTED access to released doctor reports" ($patientCanViewReleased -eq $true)

# 8. Test: File upload size limit enforcement (10MB)
$validSize = 5 * 1024 * 1024    # 5 MB
$oversizeFile = 12 * 1024 * 1024 # 12 MB
$maxLimit = 10 * 1024 * 1024     # 10 MB

Assert-Test "Valid document upload under 10MB is accepted" ($validSize -le $maxLimit)
Assert-Test "Oversized document upload exceeding 10MB is rejected" ($oversizeFile -gt $maxLimit)

# 9. Test: File MIME type whitelist enforcement
$allowedMimes = @('application/pdf', 'image/jpeg', 'image/png', 'image/webp')
$maliciousMime = 'application/x-msdownload' # .exe
$pdfMime = 'application/pdf'

Assert-Test "PDF medical document is permitted" ($allowedMimes -contains $pdfMime)
Assert-Test "Executable file MIME type is rejected" (-not ($allowedMimes -contains $maliciousMime))

# 10. Test: State Machine Transition validation
# Valid: submitted -> assigned -> under_review -> report_ready -> completed
function Test-Transition($from, $to) {
    $transitions = @{
        'draft' = @('submitted', 'cancelled');
        'submitted' = @('awaiting_assignment', 'assigned', 'cancelled');
        'awaiting_assignment' = @('assigned', 'cancelled');
        'assigned' = @('under_review', 'cancelled');
        'under_review' = @('report_ready', 'cancelled');
        'report_ready' = @('completed');
    }
    return ($transitions[$from] -contains $to)
}

Assert-Test "Valid transition: 'submitted' -> 'assigned' allowed" (Test-Transition 'submitted' 'assigned')
Assert-Test "Valid transition: 'assigned' -> 'under_review' allowed" (Test-Transition 'assigned' 'under_review')
Assert-Test "Valid transition: 'under_review' -> 'report_ready' allowed" (Test-Transition 'under_review' 'report_ready')
Assert-Test "Invalid transition: 'draft' directly to 'completed' rejected" (-not (Test-Transition 'draft' 'completed'))

# 11. Test: Rating eligibility and duplicate prevention
$eligibleCompletedCase = @{ patient_id = 'pat-1'; assigned_doctor_id = 'doc-1'; status = 'completed' }
$hasAlreadyRated = $true

$canFirstRate = ($patient1Ctx.userId -eq $eligibleCompletedCase.patient_id -and $eligibleCompletedCase.status -eq 'completed')
$canDuplicateRate = ($canFirstRate -and -not $hasAlreadyRated)

Assert-Test "Eligible patient can submit consultation rating" ($canFirstRate -eq $true)
Assert-Test "Duplicate rating submission for same interaction is rejected" ($canDuplicateRate -eq $false)

# 12. Test: Rating score range validation (1 to 5)
function Test-RatingRange($score) { return ($score -ge 1 -and $score -le 5) }
Assert-Test "Valid rating of 5 stars accepted" (Test-RatingRange 5)
Assert-Test "Invalid rating of 0 stars rejected" (-not (Test-RatingRange 0))
Assert-Test "Invalid rating of 6 stars rejected" (-not (Test-RatingRange 6))

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " TEST RUN SUMMARY: Passed: $passed, Failed: $failed" -ForegroundColor $(if ($failed -eq 0) { "Green" } else { "Red" })
Write-Host "============================================================" -ForegroundColor Cyan

if ($failed -gt 0) { exit 1 } else { exit 0 }

/**
 * Test Suite: Case Status State Machine Transitions
 * Project: SwasthyaSetu (स्वास्थ्यसेतु)
 * Enforces valid lifecycle transitions:
 * draft -> submitted -> awaiting_assignment -> assigned -> under_review -> report_ready -> completed
 */

import { CaseStatus } from '../types';

export const VALID_STATUS_TRANSITIONS: Record<CaseStatus, CaseStatus[]> = {
  draft: ['submitted', 'cancelled'],
  submitted: ['awaiting_assignment', 'assigned', 'cancelled'],
  awaiting_assignment: ['assigned', 'cancelled'],
  assigned: ['under_review', 'cancelled'],
  under_review: ['report_ready', 'cancelled'],
  report_ready: ['completed'],
  completed: [],
  cancelled: []
};

export const isValidStatusTransition = (
  currentStatus: CaseStatus,
  targetStatus: CaseStatus,
  hasAssignedDoctor: boolean
): { valid: boolean; reason?: string } => {
  if (currentStatus === targetStatus) return { valid: true };

  const allowed = VALID_STATUS_TRANSITIONS[currentStatus] || [];
  if (!allowed.includes(targetStatus)) {
    return {
      valid: false,
      reason: `Illegal state transition from '${currentStatus}' to '${targetStatus}'.`
    };
  }

  // Doctor required for under_review or report_ready
  if (['under_review', 'report_ready'].includes(targetStatus) && !hasAssignedDoctor) {
    return {
      valid: false,
      reason: `Cannot transition to '${targetStatus}' without an assigned doctor.`
    };
  }

  return { valid: true };
};

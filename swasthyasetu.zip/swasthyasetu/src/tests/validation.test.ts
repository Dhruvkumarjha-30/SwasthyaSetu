/**
 * Test Suite: File and Input Validation Rules
 * Project: SwasthyaSetu (स्वास्थ्यसेतु)
 * Tests maximum file size, permitted MIME types, rating boundaries, and email payload.
 */

export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB
export const PERMITTED_MIME_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp'
];

export const validateDocumentInput = (
  sizeBytes: number,
  mimeType: string
): { valid: boolean; error?: string } => {
  if (sizeBytes <= 0) {
    return { valid: false, error: 'File size must be greater than 0 bytes.' };
  }
  if (sizeBytes > MAX_FILE_SIZE_BYTES) {
    return { valid: false, error: 'File size exceeds 10MB limit.' };
  }
  if (!PERMITTED_MIME_TYPES.includes(mimeType)) {
    return { valid: false, error: `MIME type '${mimeType}' is not allowed.` };
  }
  return { valid: true };
};

export const validateRatingInput = (
  rating: number
): { valid: boolean; error?: string } => {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    return { valid: false, error: 'Rating must be an integer between 1 and 5.' };
  }
  return { valid: true };
};

export const validateEmailPayload = (
  payload: { reportId?: string; patientEmail?: string; patientName?: string; doctorName?: string }
): { valid: boolean; error?: string } => {
  if (!payload.reportId || !payload.patientEmail || !payload.patientName || !payload.doctorName) {
    return { valid: false, error: 'Missing required report or recipient identifiers.' };
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(payload.patientEmail)) {
    return { valid: false, error: 'Invalid recipient email format.' };
  }
  return { valid: true };
};

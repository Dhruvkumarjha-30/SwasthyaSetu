import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Stethoscope, UploadCloud, UserCheck, FileCheck, ArrowRight, ShieldCheck } from 'lucide-react';

interface HowItWorksProps {
  navigate: (route: string) => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ navigate }) => {
  const { t } = useLanguage();

  const steps = [
    {
      num: '01',
      icon: Stethoscope,
      title: 'Complete Guided Health Questionnaire',
      desc: 'Answer simple, bilingual questions in Hindi or English regarding your symptoms, fever progression, cough type, or skin discomfort.',
      color: 'bg-[#ede9fe] text-[#6d28d9]'
    },
    {
      num: '02',
      icon: UploadCloud,
      title: 'Attach Supporting Medical Documents',
      desc: 'Take a clear smartphone photo of your blood test reports, previous doctor prescriptions, or radiology scans and upload them securely.',
      color: 'bg-[#fce7f3] text-[#be185d]'
    },
    {
      num: '03',
      icon: UserCheck,
      title: 'Connect with a Verified Doctor',
      desc: 'Choose your preferred specialist or let SwasthyaSetu match you with the earliest available verified medical practitioner.',
      color: 'bg-[#e0e7ff] text-[#4338ca]'
    },
    {
      num: '04',
      icon: FileCheck,
      title: 'Receive Doctor-Authored Medical Report',
      desc: 'Access your official clinical summary, dosage schedule, lifestyle advice, and follow-up guidance in your secure portal with email notification.',
      color: 'bg-[#dcfce7] text-[#15803d]'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12 py-8">
      
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="badge badge-purple text-xs">Simple 4-Step Process</span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#1e1b4b]">
          How SwasthyaSetu Connects You With Quality Care
        </h1>
        <p className="text-sm sm:text-base text-[#6b7280] max-w-2xl mx-auto">
          We eliminate long travel hours and clinic queues for rural families by bringing certified medical consultations directly to your smartphone.
        </p>
      </div>

      {/* Process Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative">
        {steps.map((s, idx) => {
          const Icon = s.icon;
          return (
            <div key={idx} className="card relative p-8 flex flex-col justify-between hover:shadow-lg transition-all">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className={`w-14 h-14 rounded-2xl ${s.color} flex items-center justify-center`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  <span className="text-3xl font-black text-[#e9d5ff]">{s.num}</span>
                </div>
                <h3 className="text-xl font-bold text-[#1e1b4b]">{s.title}</h3>
                <p className="text-xs sm:text-sm text-[#5b557d] leading-relaxed">{s.desc}</p>
              </div>

              <div className="pt-6 border-t border-[#f3e8ff] mt-6 flex items-center gap-2 text-xs font-bold text-[#6d28d9]">
                <ShieldCheck className="w-4 h-4 text-[#16a34a]" />
                <span>Encrypted & Confidential</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* CTA Box */}
      <div className="bg-gradient-to-r from-[#6d28d9] to-[#581c87] text-white p-8 sm:p-10 rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-2xl font-extrabold">Ready to start your consultation?</h3>
        <p className="text-xs sm:text-sm text-[#ddd6fe] max-w-xl mx-auto">
          No complicated forms or tech knowledge needed. Our step-by-step assistant guides you in your language.
        </p>
        <button
          onClick={() => navigate('triage')}
          className="btn-primary bg-white text-[#581c87] hover:bg-[#f5f3ff] text-sm font-bold px-8 py-3.5 mx-auto"
        >
          <span>Start Symptom Check Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};

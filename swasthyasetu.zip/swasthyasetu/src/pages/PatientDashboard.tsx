import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { caseService } from '../services/cases';
import { reportService } from '../services/reports';
import { ratingService } from '../services/ratings';
import { documentService } from '../services/documents';
import { PatientCase, DoctorReport, MedicalDocument } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { StarRating } from '../components/StarRating';
import { 
  FileText, 
  Stethoscope, 
  Clock, 
  Download, 
  Star, 
  CheckCircle2, 
  Eye, 
  X, 
  Plus, 
  ShieldCheck, 
  Pill, 
  AlertCircle
} from 'lucide-react';

interface PatientDashboardProps {
  navigate: (route: string) => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({ navigate }) => {
  const { user } = useAuth();
  const { t } = useLanguage();

  const [cases, setCases] = useState<PatientCase[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Report Modal
  const [selectedReport, setSelectedReport] = useState<DoctorReport | null>(null);
  const [selectedCase, setSelectedCase] = useState<PatientCase | null>(null);
  const [caseDocs, setCaseDocs] = useState<MedicalDocument[]>([]);

  // Rating Modal
  const [ratingCase, setRatingCase] = useState<PatientCase | null>(null);
  const [ratingScore, setRatingScore] = useState<number>(5);
  const [ratingComment, setRatingComment] = useState<string>('');
  const [submittingRating, setSubmittingRating] = useState(false);
  const [ratingSuccess, setRatingSuccess] = useState(false);
  const [ratingError, setRatingError] = useState<string | null>(null);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    const list = await caseService.getPatientCases(user.id);
    setCases(list);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleOpenReport = async (c: PatientCase) => {
    setSelectedCase(c);
    const rep = await reportService.getReportByCaseId(c.id);
    setSelectedReport(rep);
    const docs = await documentService.getDocumentsForCase(c.id);
    setCaseDocs(docs);
  };

  const handleSubmitRating = async () => {
    if (!ratingCase || !ratingCase.assigned_doctor_id || !user) return;
    setSubmittingRating(true);
    setRatingError(null);

    const result = await ratingService.submitRating({
      caseId: ratingCase.id,
      patientId: user.id,
      doctorId: ratingCase.assigned_doctor_id,
      rating: ratingScore,
      reviewText: ratingComment
    });

    setSubmittingRating(false);
    if (result.error) {
      setRatingError(result.error);
    } else {
      setRatingSuccess(true);
      setTimeout(() => {
        setRatingCase(null);
        setRatingSuccess(false);
      }, 1800);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-8">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#581c87] to-[#7c3aed] text-white p-6 sm:p-8 rounded-3xl shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#ede9fe] uppercase tracking-wider block">Patient Health Portal</span>
          <h1 className="text-2xl sm:text-3xl font-black mt-1">
            Namaste, {user?.full_name || 'Patient'}
          </h1>
          <p className="text-xs sm:text-sm text-[#ddd6fe] mt-1">
            Track your consultations, view verified doctor reports, and access your medical history.
          </p>
        </div>

        <button
          onClick={() => navigate('triage')}
          className="btn-primary bg-white text-[#581c87] hover:bg-[#faf5ff] text-xs font-bold shadow-md shrink-0 py-2.5 px-4"
        >
          <Plus className="w-4 h-4" />
          <span>New Consultation Request</span>
        </button>
      </div>

      {/* Case Consultations Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-[#1e1b4b] flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-[#6d28d9]" />
            Your Medical Consultations
          </h2>
          <span className="text-xs text-[#6b7280]">{cases.length} Total Cases</span>
        </div>

        {loading ? (
          <div className="card text-center py-12">
            <div className="w-8 h-8 border-4 border-[#6d28d9] border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-xs text-[#6b7280] mt-2">Loading your medical records...</p>
          </div>
        ) : cases.length === 0 ? (
          <div className="card text-center py-16 space-y-3 bg-[#faf5ff] border-dashed">
            <FileText className="w-12 h-12 text-[#a78bfa] mx-auto" />
            <h3 className="text-base font-bold text-[#1e1b4b]">No Consultation Requests Yet</h3>
            <p className="text-xs text-[#6b7280] max-w-sm mx-auto">
              Whenever you take the symptom quiz and request a doctor consultation, it will appear here with live status updates.
            </p>
            <button
              onClick={() => navigate('triage')}
              className="btn-primary text-xs mx-auto mt-2"
            >
              Start First Symptom Check
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {cases.map((c) => (
              <div key={c.id} className="card p-5 hover:border-[#c4b5fd] transition-all space-y-4">
                
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#f3e8ff] pb-3">
                  <div className="flex items-center gap-2.5">
                    <StatusBadge status={c.status} />
                    <span className="text-xs text-[#6b7280]">
                      Case #{c.id.substring(0, 8)} • {new Date(c.created_at).toLocaleDateString()}
                    </span>
                  </div>

                  {/* Actions for this case */}
                  <div className="flex items-center gap-2">
                    {c.status === 'report_ready' && (
                      <button
                        onClick={() => handleOpenReport(c)}
                        className="btn-primary text-xs py-1.5 px-3 bg-[#16a34a] hover:bg-[#15803d]"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View Official Report</span>
                      </button>
                    )}

                    {(c.status === 'report_ready' || c.status === 'completed') && (
                      <button
                        onClick={() => { setRatingCase(c); setRatingError(null); }}
                        className="btn-secondary text-xs py-1.5 px-3"
                      >
                        <Star className="w-3.5 h-3.5 text-[#f59e0b]" />
                        <span>Rate Doctor</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Complaint & Symptoms */}
                <div>
                  <h4 className="font-extrabold text-sm text-[#1e1b4b]">{c.chief_complaint}</h4>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {c.symptoms.map((s, idx) => (
                      <span key={idx} className="badge badge-purple text-[11px]">
                        {s}
                      </span>
                    ))}
                    {c.duration && (
                      <span className="badge bg-[#f3f4f6] text-[#4b5563] text-[11px]">
                        Duration: {c.duration}
                      </span>
                    )}
                  </div>
                </div>

                {/* Assigned Doctor information */}
                <div className="bg-[#fcfaff] p-3 rounded-xl border border-[#ede9fe] flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-[#6b7280] block">Assigned Healthcare Provider</span>
                    <span className="font-bold text-[#4c1d95]">
                      {c.assigned_doctor_id ? 'Dr. Asha Verma (Verified General Physician)' : 'Awaiting Doctor Assignment'}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#7c3aed] font-semibold">
                    {c.status === 'under_review' ? 'Doctor Review In Progress' : ''}
                  </span>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

      {/* REPORT MODAL */}
      {selectedReport && selectedCase && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#c4b5fd] p-6 sm:p-8 space-y-6 relative">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-[#e9d5ff] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <span className="badge badge-verified text-[10px]">Official Medical Report</span>
                  <h3 className="text-xl font-black text-[#1e1b4b]">SwasthyaSetu Clinical Report</h3>
                  <p className="text-xs text-[#6b7280]">
                    Released: {selectedReport.released_at ? new Date(selectedReport.released_at).toLocaleString() : 'Recent'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedReport(null)}
                className="p-2 text-[#9ca3af] hover:text-[#1e1b4b] rounded-xl hover:bg-[#f3f4f6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Doctor & Patient Bar */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-[#faf5ff] rounded-2xl border border-[#ddd6fe] text-xs">
              <div>
                <span className="text-[#6b7280] block text-[10px]">Authoring Doctor</span>
                <span className="font-bold text-[#4c1d95]">Dr. Asha Verma (MBBS)</span>
                <span className="text-[10px] text-[#6b7280] block">Reg: MCI-UP-48921</span>
              </div>
              <div>
                <span className="text-[#6b7280] block text-[10px]">Patient Name</span>
                <span className="font-bold text-[#1e1b4b]">{user?.full_name || 'Patient'}</span>
                <span className="text-[10px] text-[#6b7280] block">Case #{selectedCase.id.substring(0, 8)}</span>
              </div>
            </div>

            {/* Diagnosis Notes */}
            <div className="space-y-2">
              <h4 className="text-xs font-extrabold text-[#4c1d95] uppercase tracking-wider">
                Clinical Diagnosis & Assessment
              </h4>
              <p className="text-xs sm:text-sm text-[#1e1b4b] bg-white p-3 rounded-xl border border-[#e9d5ff] font-medium leading-relaxed">
                {selectedReport.diagnosis_notes}
              </p>
            </div>

            {/* Prescriptions */}
            {selectedReport.prescriptions && selectedReport.prescriptions.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-extrabold text-[#4c1d95] uppercase tracking-wider flex items-center gap-1.5">
                  <Pill className="w-4 h-4 text-[#7c3aed]" />
                  Prescriptions & Dosages
                </h4>
                <div className="divide-y divide-[#f3e8ff] border border-[#e9d5ff] rounded-2xl overflow-hidden bg-white">
                  {selectedReport.prescriptions.map((p, idx) => (
                    <div key={idx} className="p-3 text-xs flex flex-col sm:flex-row justify-between gap-1">
                      <div>
                        <span className="font-bold text-[#1e1b4b] block">{p.medicine}</span>
                        <span className="text-[#6b7280] text-[11px]">{p.dosage}</span>
                      </div>
                      <span className="font-semibold text-[#6d28d9] text-[11px] self-start sm:self-center">
                        Duration: {p.duration}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Lifestyle & Dietary Advice */}
            {selectedReport.dietary_lifestyle_advice && (
              <div className="space-y-1.5">
                <h4 className="text-xs font-extrabold text-[#4c1d95] uppercase tracking-wider">
                  Diet & Lifestyle Instructions
                </h4>
                <p className="text-xs text-[#374151] bg-[#faf8ff] p-3 rounded-xl border border-[#e9d5ff]">
                  {selectedReport.dietary_lifestyle_advice}
                </p>
              </div>
            )}

            {/* Follow-up instructions */}
            {selectedReport.follow_up_recommendations && (
              <div className="space-y-1.5">
                <h4 className="text-xs font-extrabold text-[#4c1d95] uppercase tracking-wider">
                  Follow-up Guidance
                </h4>
                <p className="text-xs text-[#374151] bg-[#faf8ff] p-3 rounded-xl border border-[#e9d5ff]">
                  {selectedReport.follow_up_recommendations}
                </p>
              </div>
            )}

            {/* Print / Download Button */}
            <div className="flex justify-between items-center pt-4 border-t border-[#f3e8ff]">
              <span className="text-[11px] text-[#6b7280]">
                Signed electronically under IT Act 2000
              </span>
              <button
                onClick={() => window.print()}
                className="btn-secondary text-xs py-2 px-4 flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Print / Save PDF</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* RATING MODAL */}
      {ratingCase && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 border border-[#c4b5fd] shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base text-[#1e1b4b] flex items-center gap-2">
                <Star className="w-5 h-5 text-[#f59e0b]" />
                {t('rateDoctorTitle')}
              </h3>
              <button
                onClick={() => setRatingCase(null)}
                className="text-[#9ca3af] hover:text-[#1e1b4b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#6b7280]">
              {t('rateDoctorDesc')}
            </p>

            <div className="py-2 flex justify-center">
              <StarRating
                value={ratingScore}
                onChange={setRatingScore}
                size="lg"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#4c1d95] block mb-1">
                Your Review Comments (Optional)
              </label>
              <textarea
                rows={3}
                value={ratingComment}
                onChange={(e) => setRatingComment(e.target.value)}
                placeholder="The doctor explained everything clearly and gave good guidance..."
                className="text-xs"
              />
            </div>

            {ratingError && (
              <div className="p-2.5 bg-[#fee2e2] text-[#991b1b] rounded-xl text-xs font-semibold">
                {ratingError}
              </div>
            )}

            {ratingSuccess && (
              <div className="p-2.5 bg-[#dcfce7] text-[#15803d] rounded-xl text-xs font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>{t('ratingSuccess')}</span>
              </div>
            )}

            <button
              onClick={handleSubmitRating}
              disabled={submittingRating || ratingSuccess}
              className="w-full btn-primary text-xs py-3"
            >
              {submittingRating ? 'Submitting...' : t('submitRatingBtn')}
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

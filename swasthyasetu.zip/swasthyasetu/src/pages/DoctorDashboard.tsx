import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { caseService } from '../services/cases';
import { reportService } from '../services/reports';
import { documentService } from '../services/documents';
import { PatientCase, DoctorReport, MedicalDocument, PrescriptionItem } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { 
  Stethoscope, 
  ShieldCheck, 
  Clock, 
  FileText, 
  CheckCircle2, 
  Send, 
  Download, 
  X, 
  Plus, 
  Trash2, 
  AlertCircle,
  Eye,
  Lock
} from 'lucide-react';

interface DoctorDashboardProps {
  navigate: (route: string) => void;
}

export const DoctorDashboard: React.FC<DoctorDashboardProps> = ({ navigate }) => {
  const { user } = useAuth();
  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'assigned' | 'queue'>('assigned');
  const [assignedCases, setAssignedCases] = useState<PatientCase[]>([]);
  const [queueCases, setQueueCases] = useState<PatientCase[]>([]);
  const [loading, setLoading] = useState(true);

  // Active reviewing case
  const [reviewingCase, setReviewingCase] = useState<PatientCase | null>(null);
  const [caseDocuments, setCaseDocuments] = useState<MedicalDocument[]>([]);

  // Report editor state
  const [reportId, setReportId] = useState<string | undefined>(undefined);
  const [clinicalSummary, setClinicalSummary] = useState('');
  const [diagnosisNotes, setDiagnosisNotes] = useState('');
  const [prescriptions, setPrescriptions] = useState<PrescriptionItem[]>([
    { medicine: '', dosage: '', duration: '' }
  ]);
  const [dietAdvice, setDietAdvice] = useState('');
  const [followUp, setFollowUp] = useState('');
  const [isEmergencyReferral, setIsEmergencyReferral] = useState(false);
  const [savingReport, setSavingReport] = useState(false);
  const [editorSuccessMsg, setEditorSuccessMsg] = useState<string | null>(null);
  const [editorErrorMsg, setEditorErrorMsg] = useState<string | null>(null);

  const loadDoctorData = async () => {
    if (!user) return;
    setLoading(true);
    const assigned = await caseService.getDoctorCases(user.id);
    const queue = await caseService.getAwaitingCases();
    setAssignedCases(assigned);
    setQueueCases(queue);
    setLoading(false);
  };

  useEffect(() => {
    loadDoctorData();
  }, [user]);

  const handleOpenReview = async (c: PatientCase) => {
    setReviewingCase(c);
    setEditorSuccessMsg(null);
    setEditorErrorMsg(null);

    // Update case status to 'under_review' if it was 'assigned'
    if (c.status === 'assigned') {
      await caseService.updateStatus(c.id, 'under_review');
      c.status = 'under_review';
    }

    // Load documents
    const docs = await documentService.getDocumentsForCase(c.id);
    setCaseDocuments(docs);

    // Load existing draft or report if present
    const existing = await reportService.getReportByCaseId(c.id);
    if (existing) {
      setReportId(existing.id);
      setClinicalSummary(existing.clinical_summary || '');
      setDiagnosisNotes(existing.diagnosis_notes || '');
      setPrescriptions(existing.prescriptions || [{ medicine: '', dosage: '', duration: '' }]);
      setDietAdvice(existing.dietary_lifestyle_advice || '');
      setFollowUp(existing.follow_up_recommendations || '');
      setIsEmergencyReferral(existing.is_emergency_referral || false);
    } else {
      setReportId(undefined);
      setClinicalSummary(`Patient presents with ${c.chief_complaint}. Duration: ${c.duration || 'recent'}.`);
      setDiagnosisNotes('');
      setPrescriptions([{ medicine: 'Paracetamol 650mg', dosage: '1 tablet SOS', duration: '3 days' }]);
      setDietAdvice('Drink plenty of warm fluids and rest.');
      setFollowUp('Follow up if symptoms persist after 3 days.');
      setIsEmergencyReferral(false);
    }
  };

  const handleClaimQueueCase = async (caseId: string) => {
    if (!user) return;
    const res = await caseService.claimCase(caseId, user.id);
    if (res.success) {
      loadDoctorData();
    }
  };

  const addPrescriptionRow = () => {
    setPrescriptions([...prescriptions, { medicine: '', dosage: '', duration: '' }]);
  };

  const updatePrescriptionRow = (index: number, field: keyof PrescriptionItem, val: string) => {
    const copy = [...prescriptions];
    copy[index][field] = val;
    setPrescriptions(copy);
  };

  const removePrescriptionRow = (index: number) => {
    setPrescriptions(prescriptions.filter((_, i) => i !== index));
  };

  const handleSaveReport = async (status: 'draft' | 'released') => {
    if (!reviewingCase || !user) return;
    setSavingReport(true);
    setEditorSuccessMsg(null);
    setEditorErrorMsg(null);

    const validPrescriptions = prescriptions.filter(p => p.medicine.trim().length > 0);

    const res = await reportService.saveReport({
      id: reportId,
      caseId: reviewingCase.id,
      doctorId: user.id,
      patientId: reviewingCase.patient_id,
      clinicalSummary,
      diagnosisNotes,
      prescriptions: validPrescriptions,
      dietaryLifestyleAdvice: dietAdvice,
      followUpRecommendations: followUp,
      isEmergencyReferral,
      status
    });

    setSavingReport(false);

    if (res.error || !res.report) {
      setEditorErrorMsg(res.error || 'Failed to save report');
    } else {
      setReportId(res.report.id);
      setEditorSuccessMsg(
        status === 'released' 
          ? 'Report successfully released to patient! In-app notification & email dispatched.'
          : 'Draft report saved.'
      );
      loadDoctorData();
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-8">
      
      {/* Doctor Header Banner */}
      <div className="bg-gradient-to-r from-[#4c1d95] to-[#6d28d9] text-white p-6 sm:p-8 rounded-3xl shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="badge badge-verified bg-emerald-500/20 text-emerald-300 border-emerald-400/30 text-xs">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified Healthcare Provider
            </span>
            <span className="text-xs text-[#ddd6fe]">Reg # MCI-UP-48921</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black">
            Dr. {user?.full_name || 'Practitioner'}’s Clinical Portal
          </h1>
          <p className="text-xs sm:text-sm text-[#ddd6fe] mt-1">
            Review symptom intakes, examine diagnostic reports, and issue certified consultation findings.
          </p>
        </div>

        <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl border border-white/15 text-xs">
          <div>
            <p className="font-bold text-lg text-white">{assignedCases.length}</p>
            <p className="text-[#ddd6fe] text-[11px]">Assigned Cases</p>
          </div>
          <div className="w-px h-8 bg-white/20 mx-1"></div>
          <div>
            <p className="font-bold text-lg text-white">{queueCases.length}</p>
            <p className="text-[#ddd6fe] text-[11px]">Queue Available</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-[#e9d5ff] pb-1">
        <button
          onClick={() => setActiveTab('assigned')}
          className={`px-5 py-2.5 rounded-t-2xl text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${activeTab === 'assigned' ? 'border-[#6d28d9] text-[#6d28d9] bg-[#f5f3ff]' : 'border-transparent text-[#6b7280] hover:text-[#1e1b4b]'}`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>My Assigned Cases ({assignedCases.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('queue')}
          className={`px-5 py-2.5 rounded-t-2xl text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${activeTab === 'queue' ? 'border-[#6d28d9] text-[#6d28d9] bg-[#f5f3ff]' : 'border-transparent text-[#6b7280] hover:text-[#1e1b4b]'}`}
        >
          <Clock className="w-4 h-4" />
          <span>Unassigned Patient Queue ({queueCases.length})</span>
        </button>
      </div>

      {/* TAB CONTENT: Assigned Cases */}
      {activeTab === 'assigned' && (
        <div className="space-y-4">
          {loading ? (
            <div className="card text-center py-12">
              <div className="w-8 h-8 border-4 border-[#6d28d9] border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-[#6b7280] mt-2">Loading assigned cases...</p>
            </div>
          ) : assignedCases.length === 0 ? (
            <div className="card text-center py-12 space-y-2 bg-[#faf5ff] border-dashed">
              <Stethoscope className="w-10 h-10 text-[#a78bfa] mx-auto" />
              <h3 className="font-bold text-base text-[#1e1b4b]">No Assigned Cases</h3>
              <p className="text-xs text-[#6b7280]">Check the "Unassigned Patient Queue" tab to accept incoming consultation requests.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {assignedCases.map((c) => (
                <div key={c.id} className="card p-5 hover:border-[#c4b5fd] transition-all space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#f3e8ff] pb-3">
                    <div className="flex items-center gap-2.5">
                      <StatusBadge status={c.status} />
                      <span className="text-xs font-bold text-[#1e1b4b]">Case #{c.id.substring(0, 8)}</span>
                      <span className="text-xs text-[#6b7280]">• {new Date(c.created_at).toLocaleDateString()}</span>
                    </div>

                    <button
                      onClick={() => handleOpenReview(c)}
                      className="btn-primary text-xs py-1.5 px-4 self-start sm:self-center"
                    >
                      <span>Review & Author Report</span>
                      <FileText className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-[#1e1b4b]">{c.chief_complaint}</h4>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {c.symptoms.map((s, idx) => (
                        <span key={idx} className="badge badge-purple text-[11px]">{s}</span>
                      ))}
                      {c.emergency_flag && (
                        <span className="badge badge-emergency text-[11px]">Emergency Flag</span>
                      )}
                    </div>
                  </div>

                  {c.patient_notes && (
                    <p className="text-xs italic text-[#4b5563] bg-[#faf8ff] p-2.5 rounded-xl border border-[#ede9fe]">
                      Patient Note: "{c.patient_notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: Unassigned Queue */}
      {activeTab === 'queue' && (
        <div className="space-y-4">
          {queueCases.length === 0 ? (
            <div className="card text-center py-12 bg-[#faf5ff] border-dashed">
              <CheckCircle2 className="w-10 h-10 text-[#16a34a] mx-auto" />
              <h3 className="font-bold text-base text-[#1e1b4b] mt-2">Patient Queue Clear</h3>
              <p className="text-xs text-[#6b7280]">All submitted patient intakes have been assigned to healthcare providers.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {queueCases.map((c) => (
                <div key={c.id} className="card p-5 hover:border-[#c4b5fd] transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="badge badge-purple text-[10px]">Awaiting Doctor</span>
                      <span className="text-xs text-[#6b7280]">{new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <h4 className="font-extrabold text-sm text-[#1e1b4b]">{c.chief_complaint}</h4>
                    <div className="flex flex-wrap gap-1">
                      {c.symptoms.map((s, idx) => (
                        <span key={idx} className="badge bg-[#f3f4f6] text-[#4b5563] text-[10px]">{s}</span>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => handleClaimQueueCase(c.id)}
                    className="btn-primary text-xs py-2 px-4 whitespace-nowrap self-stretch sm:self-auto"
                  >
                    <span>Accept Case Consultation</span>
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* CASE REVIEW & REPORT AUTHORING MODAL */}
      {reviewingCase && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#c4b5fd] p-6 sm:p-8 space-y-6 relative">
            
            {/* Header */}
            <div className="flex items-start justify-between border-b border-[#e9d5ff] pb-4">
              <div>
                <span className="badge badge-purple text-[10px]">Clinical Review Suite</span>
                <h3 className="text-xl font-black text-[#1e1b4b] mt-1">
                  Case Review #{reviewingCase.id.substring(0, 8)}
                </h3>
                <p className="text-xs text-[#6b7280]">
                  Chief Complaint: {reviewingCase.chief_complaint}
                </p>
              </div>

              <button
                onClick={() => setReviewingCase(null)}
                className="p-2 text-[#9ca3af] hover:text-[#1e1b4b] rounded-xl hover:bg-[#f3f4f6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Patient Symptoms & Questionnaire Answers */}
            <div className="p-4 bg-[#faf8ff] rounded-2xl border border-[#e9d5ff] space-y-3 text-xs">
              <h4 className="font-extrabold text-[#4c1d95] uppercase tracking-wider text-[11px]">
                Intake Questionnaire Responses
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {Object.entries(reviewingCase.questionnaire_responses || {}).map(([k, v], idx) => (
                  <div key={idx} className="bg-white p-2.5 rounded-xl border border-[#f3e8ff]">
                    <span className="text-[#6b7280] block text-[10px]">{k}</span>
                    <span className="font-semibold text-[#1e1b4b]">{String(v)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Attached Patient Documents */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-[#4c1d95] uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#16a34a]" />
                Patient Medical Documents ({caseDocuments.length})
              </h4>
              {caseDocuments.length === 0 ? (
                <p className="text-xs text-[#6b7280] italic bg-[#f9fafb] p-3 rounded-xl border border-[#e5e7eb]">
                  No supporting documents were attached for this intake.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {caseDocuments.map((doc) => (
                    <div key={doc.id} className="p-3 bg-white border border-[#ddd6fe] rounded-xl flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 overflow-hidden">
                        <FileText className="w-4 h-4 text-[#6d28d9] shrink-0" />
                        <span className="truncate font-semibold text-[#1e1b4b]">{doc.document_name}</span>
                      </div>
                      <button
                        onClick={async () => {
                          const url = await documentService.getAuthorizedDownloadUrl(doc.storage_path);
                          if (url) window.open(url, '_blank');
                        }}
                        className="text-xs font-bold text-[#6d28d9] hover:underline shrink-0 ml-2"
                      >
                        View / Download
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Report Authoring Fields */}
            <div className="space-y-4 pt-4 border-t border-[#e9d5ff]">
              <h4 className="font-extrabold text-base text-[#1e1b4b]">
                {t('authorReportTitle')}
              </h4>

              {/* Diagnosis Notes */}
              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">
                  Diagnosis / Clinical Evaluation *
                </label>
                <textarea
                  rows={2}
                  required
                  value={diagnosisNotes}
                  onChange={(e) => setDiagnosisNotes(e.target.value)}
                  placeholder="e.g. Acute Viral Upper Respiratory Infection without lower tract involvement."
                  className="text-xs"
                />
              </div>

              {/* Clinical Summary */}
              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">
                  Clinical Summary & Observations
                </label>
                <textarea
                  rows={2}
                  value={clinicalSummary}
                  onChange={(e) => setClinicalSummary(e.target.value)}
                  placeholder="Observations based on questionnaire and history..."
                  className="text-xs"
                />
              </div>

              {/* Prescriptions Builder */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#4c1d95]">
                    Prescription Medicines & Dosages
                  </label>
                  <button
                    type="button"
                    onClick={addPrescriptionRow}
                    className="text-xs text-[#7c3aed] font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Medicine</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {prescriptions.map((p, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-[#faf5ff] p-2.5 rounded-xl border border-[#e9d5ff]">
                      <input
                        type="text"
                        placeholder="Medicine name (e.g. Paracetamol 650mg)"
                        value={p.medicine}
                        onChange={(e) => updatePrescriptionRow(idx, 'medicine', e.target.value)}
                        className="text-xs min-h-[38px] flex-2"
                      />
                      <input
                        type="text"
                        placeholder="Dosage (e.g. 1 tab after food)"
                        value={p.dosage}
                        onChange={(e) => updatePrescriptionRow(idx, 'dosage', e.target.value)}
                        className="text-xs min-h-[38px] flex-2"
                      />
                      <input
                        type="text"
                        placeholder="Duration (e.g. 3 days)"
                        value={p.duration}
                        onChange={(e) => updatePrescriptionRow(idx, 'duration', e.target.value)}
                        className="text-xs min-h-[38px] flex-1"
                      />
                      {prescriptions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removePrescriptionRow(idx)}
                          className="text-[#9ca3af] hover:text-[#dc2626] p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Diet & Lifestyle Advice */}
              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">
                  Diet & Lifestyle Guidance
                </label>
                <input
                  type="text"
                  value={dietAdvice}
                  onChange={(e) => setDietAdvice(e.target.value)}
                  placeholder="e.g. Drink warm fluids, avoid cold exposure, rest 48h."
                  className="text-xs"
                />
              </div>

              {/* Follow up */}
              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">
                  Follow-up Guidance
                </label>
                <input
                  type="text"
                  value={followUp}
                  onChange={(e) => setFollowUp(e.target.value)}
                  placeholder="e.g. Visit Community Health Centre if fever persists past 3 days."
                  className="text-xs"
                />
              </div>
            </div>

            {editorErrorMsg && (
              <div className="p-3 bg-[#fee2e2] text-[#991b1b] rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{editorErrorMsg}</span>
              </div>
            )}

            {editorSuccessMsg && (
              <div className="p-3 bg-[#dcfce7] text-[#15803d] rounded-xl text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{editorSuccessMsg}</span>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-4 border-t border-[#e9d5ff]">
              <button
                type="button"
                disabled={savingReport}
                onClick={() => handleSaveReport('draft')}
                className="btn-secondary text-xs py-2.5 px-5 w-full sm:w-auto"
              >
                <span>Save Draft</span>
              </button>

              <button
                type="button"
                disabled={savingReport || !diagnosisNotes.trim()}
                onClick={() => handleSaveReport('released')}
                className="btn-primary text-xs py-2.5 px-6 shadow-md w-full sm:w-auto bg-[#16a34a] hover:bg-[#15803d]"
              >
                <Send className="w-4 h-4" />
                <span>Release Official Report to Patient</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};

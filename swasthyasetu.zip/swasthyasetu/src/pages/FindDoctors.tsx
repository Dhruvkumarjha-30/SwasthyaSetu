import React, { useState, useEffect } from 'react';
import { doctorService } from '../services/doctors';
import { DoctorProfile } from '../types';
import { DoctorCard } from '../components/DoctorCard';
import { useLanguage } from '../contexts/LanguageContext';
import { Search, Filter, Stethoscope, AlertCircle, RefreshCw } from 'lucide-react';

interface FindDoctorsProps {
  navigate: (route: string) => void;
  onSelectDoctor?: (doc: DoctorProfile) => void;
}

export const FindDoctors: React.FC<FindDoctorsProps> = ({ navigate, onSelectDoctor }) => {
  const { t } = useLanguage();
  const [doctors, setDoctors] = useState<DoctorProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [specialtyFilter, setSpecialtyFilter] = useState('all');
  const [languageFilter, setLanguageFilter] = useState('all');

  const fetchDoctors = async () => {
    setLoading(true);
    const { doctors: list } = await doctorService.getDoctors({
      searchQuery: searchQuery.trim(),
      specialty: specialtyFilter,
      language: languageFilter
    });
    setDoctors(list);
    setLoading(false);
  };

  useEffect(() => {
    fetchDoctors();
  }, [specialtyFilter, languageFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchDoctors();
  };

  const handleDoctorSelected = (doc: DoctorProfile) => {
    if (onSelectDoctor) {
      onSelectDoctor(doc);
    }
    // Store selected doctor in sessionStorage for triage flow
    sessionStorage.setItem('swasthyasetu_selected_doctor', JSON.stringify(doc));
    navigate('triage');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 py-8">
      
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-extrabold text-[#1e1b4b]">
          Verified Doctors & Specialists
        </h1>
        <p className="text-sm text-[#6b7280]">
          Connect with state medical council registered practitioners available for consultation.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="card bg-white p-5 space-y-4 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-[#9ca3af] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchDoctorPlaceholder')}
              className="pl-11 h-12 text-sm bg-[#faf8ff] border border-[#ddd6fe] rounded-xl"
            />
          </div>

          <button type="submit" className="btn-primary text-sm whitespace-nowrap h-12 px-6">
            Search Doctors
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-[#f3e8ff]">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#6d28d9]">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          {/* Specialty Dropdown */}
          <select
            value={specialtyFilter}
            onChange={(e) => setSpecialtyFilter(e.target.value)}
            className="w-auto h-9 text-xs bg-[#faf8ff] border border-[#ddd6fe] rounded-lg py-1 px-3"
          >
            <option value="all">{t('filterAllSpecialties')}</option>
            <option value="General Physician">General Physician (सामान्य चिकित्सक)</option>
            <option value="Dermatology">Dermatology (त्वचा रोग)</option>
            <option value="Pulmonology">Pulmonology (श्वसन / फेफड़े)</option>
            <option value="Pediatrics">Pediatrics (बाल रोग)</option>
          </select>

          {/* Language Dropdown */}
          <select
            value={languageFilter}
            onChange={(e) => setLanguageFilter(e.target.value)}
            className="w-auto h-9 text-xs bg-[#faf8ff] border border-[#ddd6fe] rounded-lg py-1 px-3"
          >
            <option value="all">{t('filterAllLanguages')}</option>
            <option value="Hindi">Hindi (हिंदी)</option>
            <option value="English">English</option>
            <option value="Urdu">Urdu (उर्दू)</option>
          </select>

          <button
            onClick={() => {
              setSearchQuery('');
              setSpecialtyFilter('all');
              setLanguageFilter('all');
              fetchDoctors();
            }}
            className="text-xs text-[#7c3aed] hover:underline font-semibold ml-auto flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            Reset Filters
          </button>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      {loading ? (
        <div className="py-16 text-center space-y-3">
          <div className="w-10 h-10 border-4 border-[#6d28d9] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-[#6b7280]">Loading verified doctors...</p>
        </div>
      ) : doctors.length === 0 ? (
        <div className="card text-center py-12 space-y-3 bg-[#faf5ff] border-dashed">
          <AlertCircle className="w-8 h-8 text-[#9333ea] mx-auto" />
          <h3 className="font-bold text-base text-[#1e1b4b]">{t('noDoctorsFound')}</h3>
          <p className="text-xs text-[#6b7280]">Try clearing search keywords or changing filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctors.map((doc) => (
            <DoctorCard
              key={doc.id}
              doctor={doc}
              onSelect={handleDoctorSelected}
            />
          ))}
        </div>
      )}

    </div>
  );
};

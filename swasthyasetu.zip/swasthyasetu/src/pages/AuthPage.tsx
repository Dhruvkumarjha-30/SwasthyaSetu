import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';
import { Activity, Lock, Mail, User, Phone, Stethoscope, ShieldCheck, ArrowRight } from 'lucide-react';

interface AuthPageProps {
  navigate: (route: string) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ navigate }) => {
  const { signIn, signUp, switchDemoRole } = useAuth();

  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<UserRole>('patient');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');

  // Doctor-specific fields
  const [specialty, setSpecialty] = useState('General Physician');
  const [qualifications, setQualifications] = useState('MBBS');
  const [experienceYears, setExperienceYears] = useState(5);
  const [clinicLocation, setClinicLocation] = useState('');
  const [consultationFee, setConsultationFee] = useState(300);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    if (isLogin) {
      const res = await signIn(email, password);
      setLoading(false);
      if (res.error) {
        setErrorMsg(res.error);
      } else {
        navigate(email.includes('asha') || email.includes('doc') ? 'doctor-dashboard' : 'patient-dashboard');
      }
    } else {
      const res = await signUp({
        email,
        password,
        fullName,
        role,
        phone,
        specialty: role === 'doctor' ? specialty : undefined,
        qualifications: role === 'doctor' ? qualifications : undefined,
        experienceYears: role === 'doctor' ? Number(experienceYears) : undefined,
        clinicLocation: role === 'doctor' ? clinicLocation : undefined,
        consultationFee: role === 'doctor' ? Number(consultationFee) : undefined,
      });

      setLoading(false);
      if (res.error) {
        setErrorMsg(res.error);
      } else {
        navigate(role === 'doctor' ? 'doctor-dashboard' : 'patient-dashboard');
      }
    }
  };

  return (
    <div className="max-w-md mx-auto py-12 px-4">
      <div className="card shadow-xl p-8 space-y-6">
        
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#6d28d9] to-[#4c1d95] text-white rounded-2xl flex items-center justify-center mx-auto shadow-md">
            <Activity className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-black text-[#1e1b4b]">
            {isLogin ? 'Sign In to SwasthyaSetu' : 'Create Your Account'}
          </h2>
          <p className="text-xs text-[#6b7280]">
            {isLogin ? 'Access your medical records or doctor dashboard' : 'Join the healthcare network for rural access'}
          </p>
        </div>

        {/* Tab Switcher: Login vs Sign Up */}
        <div className="flex bg-[#f5f3ff] p-1 rounded-xl border border-[#e9d5ff]">
          <button
            type="button"
            onClick={() => { setIsLogin(true); setErrorMsg(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${isLogin ? 'bg-[#6d28d9] text-white shadow-xs' : 'text-[#6b7280] hover:text-[#1e1b4b]'}`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => { setIsLogin(false); setErrorMsg(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${!isLogin ? 'bg-[#6d28d9] text-white shadow-xs' : 'text-[#6b7280] hover:text-[#1e1b4b]'}`}
          >
            New Registration
          </button>
        </div>

        {/* Role Toggle if registering */}
        {!isLogin && (
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#4c1d95] block">Select Account Role</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setRole('patient')}
                className={`p-3 rounded-xl border-2 text-xs font-bold flex items-center justify-center gap-2 transition-all ${role === 'patient' ? 'border-[#6d28d9] bg-[#faf5ff] text-[#4c1d95]' : 'border-[#e9d5ff] bg-white text-[#6b7280]'}`}
              >
                <User className="w-4 h-4" />
                <span>Patient (रोगी)</span>
              </button>
              <button
                type="button"
                onClick={() => setRole('doctor')}
                className={`p-3 rounded-xl border-2 text-xs font-bold flex items-center justify-center gap-2 transition-all ${role === 'doctor' ? 'border-[#6d28d9] bg-[#faf5ff] text-[#4c1d95]' : 'border-[#e9d5ff] bg-white text-[#6b7280]'}`}
              >
                <Stethoscope className="w-4 h-4" />
                <span>Doctor (चिकित्सक)</span>
              </button>
            </div>
          </div>
        )}

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {!isLogin && (
            <>
              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">Full Legal Name</label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#9ca3af] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Ramesh Kumar"
                    className="pl-10 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#4c1d95] block mb-1">Mobile Number (Optional)</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#9ca3af] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="pl-10 text-xs"
                  />
                </div>
              </div>

              {/* Doctor Registration Fields */}
              {role === 'doctor' && (
                <div className="p-4 bg-[#faf5ff] rounded-2xl border border-[#ddd6fe] space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#6d28d9]">
                    <ShieldCheck className="w-4 h-4 text-[#16a34a]" />
                    <span>Doctor Verification Details</span>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[#374151] block mb-1">Specialty</label>
                    <select
                      value={specialty}
                      onChange={(e) => setSpecialty(e.target.value)}
                      className="text-xs"
                    >
                      <option value="General Physician">General Physician</option>
                      <option value="Dermatology">Dermatology</option>
                      <option value="Pulmonology">Pulmonology</option>
                      <option value="Pediatrics">Pediatrics</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[#374151] block mb-1">Degrees & Qualifications</label>
                    <input
                      type="text"
                      required
                      value={qualifications}
                      onChange={(e) => setQualifications(e.target.value)}
                      placeholder="e.g. MBBS, MD"
                      className="text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-bold text-[#374151] block mb-1">Exp (Years)</label>
                      <input
                        type="number"
                        min="0"
                        value={experienceYears}
                        onChange={(e) => setExperienceYears(Number(e.target.value))}
                        className="text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-[#374151] block mb-1">Fee (₹)</label>
                      <input
                        type="number"
                        min="0"
                        value={consultationFee}
                        onChange={(e) => setConsultationFee(Number(e.target.value))}
                        className="text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-[#374151] block mb-1">Clinic / Hospital Location</label>
                    <input
                      type="text"
                      required
                      value={clinicLocation}
                      onChange={(e) => setClinicLocation(e.target.value)}
                      placeholder="e.g. Primary Health Centre, Mathura"
                      className="text-xs"
                    />
                  </div>
                </div>
              )}
            </>
          )}

          <div>
            <label className="text-xs font-bold text-[#4c1d95] block mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#9ca3af] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="pl-10 text-xs"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-[#4c1d95] block mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#9ca3af] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="pl-10 text-xs"
              />
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-[#fee2e2] text-[#991b1b] rounded-xl text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full btn-primary text-sm font-bold shadow-md"
          >
            <span>{loading ? 'Please wait...' : (isLogin ? 'Sign In' : 'Create Account')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Demo Fast Logins for judges and review */}
        <div className="pt-4 border-t border-[#f3e8ff] space-y-2">
          <p className="text-[11px] text-center text-[#6b7280] font-semibold">Quick Demo Login (No password needed):</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                switchDemoRole('patient');
                navigate('patient-dashboard');
              }}
              className="p-2 rounded-xl text-xs font-bold bg-[#f5f3ff] text-[#6d28d9] border border-[#ddd6fe] hover:bg-[#ede9fe]"
            >
              Demo Patient →
            </button>
            <button
              type="button"
              onClick={() => {
                switchDemoRole('doctor');
                navigate('doctor-dashboard');
              }}
              className="p-2 rounded-xl text-xs font-bold bg-[#f5f3ff] text-[#6d28d9] border border-[#ddd6fe] hover:bg-[#ede9fe]"
            >
              Demo Doctor →
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

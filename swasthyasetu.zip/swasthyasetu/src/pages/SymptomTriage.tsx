import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { caseService } from '../services/cases';
import { doctorService } from '../services/doctors';
import { DoctorProfile, MedicalDocument } from '../types';
import { DocumentUpload } from '../components/DocumentUpload';
import { DoctorCard } from '../components/DoctorCard';
import { EmergencyBanner } from '../components/EmergencyBanner';
import { 
  Stethoscope, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  FileText, 
  UserCheck, 
  ShieldCheck,
  Send
} from 'lucide-react';

interface SymptomTriageProps {
  navigate: (route: string) => void;
}

const ALL_SYMPTOMS = [
  'Fever',
  'Cough',
  'Sore throat',
  'Headache',
  'Body ache',
  'Stomach discomfort',
  'Nausea or vomiting',
  'Skin concerns',
  'Breathing difficulty',
  'Other symptoms'
];

const EMERGENCY_RED_FLAGS = [
  'Severe difficulty breathing',
  'Chest pain or pressure',
  'Fainting or loss of consciousness',
  'Heavy or uncontrollable bleeding'
];

export const SymptomTriage: React.FC<SymptomTriageProps> = ({ navigate }) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  // Multi-step form state: 1 = Symptoms, 2 = Questions, 3 = Documents, 4 = Doctor Selection, 5 = Review & Submit
  const [step, setStep] = useState(1);

  // Form answers
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [selectedRedFlags, setSelectedRedFlags] = useState<string[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [uploadedDocs, setUploadedDocs] = useState<MedicalDocument[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<DoctorProfile | null>(null);
  const [availableDoctors, setAvailableDoctors] = useState<DoctorProfile[]>([]);
  const [patientNotes, setPatientNotes] = useState('');
  const [consentAgreed, setConsentAgreed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Check if a pre-selected doctor was stored in sessionStorage
  useEffect(() => {
    const savedDoc = sessionStorage.getItem('swasthyasetu_selected_doctor');
    if (savedDoc) {
      try {
        setSelectedDoctor(JSON.parse(savedDoc));
      } catch (e) {
        console.error(e);
      }
    }

    doctorService.getDoctors().then(res => setAvailableDoctors(res.doctors));
  }, []);

  const toggleSymptom = (sym: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(sym) ? prev.filter(s => s !== sym) : [...prev, sym]
    );
  };

  const toggleRedFlag = (rf: string) => {
    setSelectedRedFlags(prev => 
      prev.includes(rf) ? prev.filter(s => s !== rf) : [...prev, rf]
    );
  };

  const handleAnswer = (question: string, val: string) => {
    setAnswers(prev => ({ ...prev, [question]: val }));
  };

  const hasEmergency = selectedRedFlags.length > 0 || 
    (selectedSymptoms.includes('Breathing difficulty') && answers['Is breathing difficult even when resting?'] === 'Yes');

  const handleSubmit = async () => {
    if (!consentAgreed) {
      setSubmitError('Please accept the consent checkbox to continue.');
      return;
    }

    if (!user) {
      // Prompt user to login/register first, preserve state
      sessionStorage.setItem('swasthyasetu_pending_triage', JSON.stringify({
        selectedSymptoms,
        answers,
        selectedDoctorId: selectedDoctor?.id,
        patientNotes
      }));
      navigate('auth');
      return;
    }

    setSubmitting(true);
    setSubmitError(null);

    const chiefComplaint = selectedSymptoms.length > 0
      ? `${selectedSymptoms.join(', ')} reported`
      : 'General medical consultation';

    const duration = answers['Duration'] || answers['Fever: when did it start?'] || 'Not specified';

    const result = await caseService.createCase({
      patientId: user.id,
      assignedDoctorId: selectedDoctor?.id || null,
      chiefComplaint,
      symptoms: selectedSymptoms,
      duration,
      questionnaireResponses: answers,
      emergencyFlag: hasEmergency,
      patientNotes
    });

    setSubmitting(false);

    if (result.error || !result.caseItem) {
      setSubmitError(result.error || 'Failed to submit case.');
    } else {
      // Clear session storage and navigate to dashboard
      sessionStorage.removeItem('swasthyasetu_selected_doctor');
      sessionStorage.removeItem('swasthyasetu_pending_triage');
      navigate('patient-dashboard');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-8">
      
      {/* Top Header */}
      <div className="space-y-2 text-center">
        <span className="badge badge-purple text-xs">Guided Health Intake</span>
        <h1 className="text-3xl font-extrabold text-[#1e1b4b]">
          {t('triageTitle')}
        </h1>
        <p className="text-xs sm:text-sm text-[#6b7280]">
          {t('triageSubtitle')}
        </p>
      </div>

      {/* Red Flag Emergency Warning if triggered */}
      {hasEmergency && (
        <div className="animate-bounce">
          <EmergencyBanner />
        </div>
      )}

      {/* Stepper Progress Bar */}
      <div className="flex items-center justify-between max-w-lg mx-auto px-4">
        {[1, 2, 3, 4, 5].map((s) => (
          <div key={s} className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${step >= s ? 'bg-[#6d28d9] text-white shadow-md' : 'bg-[#e9d5ff] text-[#581c87]'}`}>
              {s}
            </div>
            {s < 5 && (
              <div className={`w-10 sm:w-16 h-1 transition-all ${step > s ? 'bg-[#6d28d9]' : 'bg-[#e9d5ff]'}`} />
            )}
          </div>
        ))}
      </div>

      {/* STEP 1: Select Symptoms & Red Flags */}
      {step === 1 && (
        <div className="card space-y-6">
          <div>
            <h3 className="text-lg font-bold text-[#1e1b4b] flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-[#6d28d9]" />
              {t('selectSymptoms')}
            </h3>
            <p className="text-xs text-[#6b7280] mt-1">Tap all symptoms that apply to you right now.</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {ALL_SYMPTOMS.map((sym) => {
              const checked = selectedSymptoms.includes(sym);
              return (
                <button
                  key={sym}
                  type="button"
                  onClick={() => toggleSymptom(sym)}
                  className={`p-3.5 rounded-2xl border-2 text-left font-semibold text-xs sm:text-sm transition-all flex items-center justify-between ${checked ? 'border-[#6d28d9] bg-[#f5f3ff] text-[#4c1d95] shadow-xs' : 'border-[#e9d5ff] bg-white text-[#374151] hover:border-[#c4b5fd]'}`}
                >
                  <span>{sym}</span>
                  {checked && <CheckCircle2 className="w-4 h-4 text-[#6d28d9]" />}
                </button>
              );
            })}
          </div>

          {/* Emergency Safety Screen Section */}
          <div className="pt-4 border-t border-[#f3e8ff]">
            <h4 className="text-xs font-bold text-[#b91c1c] flex items-center gap-1.5 mb-2">
              <AlertTriangle className="w-4 h-4 text-[#dc2626]" />
              Do you have any of these severe signs?
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {EMERGENCY_RED_FLAGS.map((rf) => {
                const checked = selectedRedFlags.includes(rf);
                return (
                  <button
                    key={rf}
                    type="button"
                    onClick={() => toggleRedFlag(rf)}
                    className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all ${checked ? 'border-[#ef4444] bg-[#fef2f2] text-[#991b1b] font-bold' : 'border-[#fed7aa] bg-[#fffbeb] text-[#9a3412] hover:bg-[#fef3c7]'}`}
                  >
                    <span>⚠️ {rf}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button
              disabled={selectedSymptoms.length === 0}
              onClick={() => setStep(2)}
              className="btn-primary text-sm px-6"
            >
              <span>Continue to Questions</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Conditional Questionnaire */}
      {step === 2 && (
        <div className="card space-y-6">
          <div>
            <h3 className="text-lg font-bold text-[#1e1b4b]">
              Detailed Questions
            </h3>
            <p className="text-xs text-[#6b7280]">
              These details help your consulting doctor understand your symptom timeline.
            </p>
          </div>

          <div className="space-y-5">
            {/* General duration */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#4c1d95]">
                How long have you had these symptoms in total?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {['Started today', '1–2 days', '3–7 days', 'More than 1 week'].map((dur) => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => handleAnswer('Duration', dur)}
                    className={`p-3 rounded-xl border text-xs font-semibold ${answers['Duration'] === dur ? 'border-[#6d28d9] bg-[#ede9fe] text-[#4c1d95]' : 'border-[#e9d5ff] bg-white text-[#4b5563]'}`}
                  >
                    {dur}
                  </button>
                ))}
              </div>
            </div>

            {/* Fever Questions */}
            {selectedSymptoms.includes('Fever') && (
              <div className="p-4 bg-[#faf5ff] rounded-2xl border border-[#ddd6fe] space-y-4">
                <h4 className="font-bold text-xs text-[#6d28d9]">Fever Assessment</h4>
                <div className="space-y-1.5">
                  <label className="text-xs text-[#374151]">How is the fever progressing?</label>
                  <div className="flex gap-2">
                    {['Getting worse', 'Staying the same', 'Improving'].map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleAnswer('Fever Progression', opt)}
                        className={`px-3 py-2 rounded-xl text-xs font-medium border ${answers['Fever Progression'] === opt ? 'border-[#6d28d9] bg-[#6d28d9] text-white' : 'border-[#ddd6fe] bg-white'}`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-[#374151]">Have you taken any fever medicine (Paracetamol)?</label>
                  <div className="flex gap-2">
                    {['No', 'Yes – I will inform the doctor'].map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleAnswer('Fever Meds', opt)}
                        className={`px-3 py-2 rounded-xl text-xs font-medium border ${answers['Fever Meds'] === opt ? 'border-[#6d28d9] bg-[#6d28d9] text-white' : 'border-[#ddd6fe] bg-white'}`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Cough Questions */}
            {selectedSymptoms.includes('Cough') && (
              <div className="p-4 bg-[#faf5ff] rounded-2xl border border-[#ddd6fe] space-y-3">
                <h4 className="font-bold text-xs text-[#6d28d9]">Cough Assessment</h4>
                <label className="text-xs text-[#374151]">What type of cough are you experiencing?</label>
                <div className="flex gap-2">
                  {['Dry cough (सूखी खांसी)', 'With phlegm / mucus (बलगम वाली खांसी)', 'Not sure'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => handleAnswer('Cough Type', opt)}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border ${answers['Cough Type'] === opt ? 'border-[#6d28d9] bg-[#6d28d9] text-white' : 'border-[#ddd6fe] bg-white'}`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Breathing Difficulty Questions */}
            {selectedSymptoms.includes('Breathing difficulty') && (
              <div className="p-4 bg-[#fff1f2] rounded-2xl border border-[#fecdd3] space-y-3">
                <h4 className="font-bold text-xs text-[#be123c]">Breathing Evaluation</h4>
                <label className="text-xs text-[#9f1239]">Is breathing difficult even when resting quietly?</label>
                <div className="flex gap-2">
                  {['Yes', 'Only during physical exertion', 'No'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => handleAnswer('Is breathing difficult even when resting?', opt)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border ${answers['Is breathing difficult even when resting?'] === opt ? 'border-[#e11d48] bg-[#e11d48] text-white' : 'border-[#fecdd3] bg-white text-[#9f1239]'}`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Additional Patient Notes */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#4c1d95]">
                {t('additionalNotes')}
              </label>
              <textarea
                rows={3}
                value={patientNotes}
                onChange={(e) => setPatientNotes(e.target.value)}
                placeholder={t('additionalNotesPlaceholder')}
                className="text-xs"
              />
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(1)} className="btn-secondary text-sm">
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button onClick={() => setStep(3)} className="btn-primary text-sm px-6">
              <span>Next: Documents</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Document Uploads */}
      {step === 3 && (
        <div className="card space-y-6">
          <div>
            <h3 className="text-lg font-bold text-[#1e1b4b]">
              {t('uploadDocsTitle')}
            </h3>
            <p className="text-xs text-[#6b7280]">
              {t('uploadDocsDesc')}
            </p>
          </div>

          <DocumentUpload
            patientId={user?.id || 'pending-user'}
            onUploaded={(doc) => setUploadedDocs(prev => [...prev, doc])}
          />

          {uploadedDocs.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-[#4c1d95]">Attached Documents ({uploadedDocs.length})</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {uploadedDocs.map((doc, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-2.5 bg-white border border-[#ddd6fe] rounded-xl text-xs">
                    <FileText className="w-4 h-4 text-[#6d28d9] shrink-0" />
                    <span className="truncate font-medium">{doc.document_name}</span>
                    <span className="badge badge-verified text-[10px] ml-auto">Ready</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(2)} className="btn-secondary text-sm">
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button onClick={() => setStep(4)} className="btn-primary text-sm px-6">
              <span>Next: Select Doctor</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Doctor Selection */}
      {step === 4 && (
        <div className="card space-y-6">
          <div>
            <h3 className="text-lg font-bold text-[#1e1b4b]">
              {t('chooseDoctorTitle')}
            </h3>
            <p className="text-xs text-[#6b7280]">
              Pick an MBBS or specialist doctor, or select auto-assign for the fastest turnaround.
            </p>
          </div>

          {/* Auto assign card */}
          <div
            onClick={() => setSelectedDoctor(null)}
            className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${!selectedDoctor ? 'border-[#6d28d9] bg-[#faf5ff] ring-2 ring-[#c4b5fd]' : 'border-[#e9d5ff] bg-white hover:border-[#c4b5fd]'}`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center font-bold text-sm">
                ⚡
              </div>
              <div>
                <p className="font-extrabold text-sm text-[#1e1b4b]">{t('autoAssignDoctor')}</p>
                <p className="text-xs text-[#6b7280]">Our matching engine assigns the next available verified practitioner.</p>
              </div>
            </div>
            {!selectedDoctor && <CheckCircle2 className="w-5 h-5 text-[#6d28d9]" />}
          </div>

          {/* List of specific doctors */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#6b7280]">Or choose a specific specialist:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availableDoctors.map((doc) => (
                <DoctorCard
                  key={doc.id}
                  doctor={doc}
                  selected={selectedDoctor?.id === doc.id}
                  onSelect={(d) => setSelectedDoctor(d)}
                />
              ))}
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(3)} className="btn-secondary text-sm">
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button onClick={() => setStep(5)} className="btn-primary text-sm px-6">
              <span>Next: Final Review</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: Review & Consent & Submit */}
      {step === 5 && (
        <div className="card space-y-6">
          <div>
            <h3 className="text-xl font-extrabold text-[#1e1b4b]">
              Review & Submit Consultation
            </h3>
            <p className="text-xs text-[#6b7280]">
              Please verify your information before transmitting to the clinical portal.
            </p>
          </div>

          {/* Summary Box */}
          <div className="bg-[#faf8ff] p-5 rounded-2xl border border-[#e9d5ff] space-y-3 text-xs">
            <div className="flex justify-between border-b border-[#f3e8ff] pb-2">
              <span className="font-bold text-[#4c1d95]">Symptoms:</span>
              <span className="font-semibold text-[#1e1b4b]">{selectedSymptoms.join(', ') || 'None selected'}</span>
            </div>

            <div className="flex justify-between border-b border-[#f3e8ff] pb-2">
              <span className="font-bold text-[#4c1d95]">Consulting Doctor:</span>
              <span className="font-semibold text-[#1e1b4b]">
                {selectedDoctor ? selectedDoctor.full_name : 'Auto-assign available verified doctor'}
              </span>
            </div>

            <div className="flex justify-between border-b border-[#f3e8ff] pb-2">
              <span className="font-bold text-[#4c1d95]">Attached Documents:</span>
              <span className="font-semibold text-[#1e1b4b]">{uploadedDocs.length} files attached</span>
            </div>

            {patientNotes && (
              <div className="border-b border-[#f3e8ff] pb-2">
                <span className="font-bold text-[#4c1d95] block mb-1">Patient Note:</span>
                <p className="italic text-[#4b5563]">"{patientNotes}"</p>
              </div>
            )}
          </div>

          {/* Consent Checkbox */}
          <div className="bg-[#f5f3ff] p-4 rounded-xl border border-[#ddd6fe]">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={consentAgreed}
                onChange={(e) => setConsentAgreed(e.target.checked)}
                className="w-5 h-5 rounded border-[#c4b5fd] text-[#6d28d9] focus:ring-[#7c3aed] mt-0.5"
              />
              <span className="text-xs text-[#374151] leading-relaxed">
                {t('consentCheckbox')}
              </span>
            </label>
          </div>

          {submitError && (
            <div className="p-3 bg-[#fee2e2] text-[#991b1b] rounded-xl text-xs font-semibold">
              {submitError}
            </div>
          )}

          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(4)} className="btn-secondary text-sm">
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              onClick={handleSubmit}
              disabled={submitting || !consentAgreed}
              className="btn-primary text-sm px-8 shadow-md"
            >
              <Send className="w-4 h-4" />
              <span>{submitting ? t('submitting') : t('submitConsultationBtn')}</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

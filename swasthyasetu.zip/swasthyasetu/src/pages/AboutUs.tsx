import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Activity, ShieldCheck, HeartHandshake, Award, Users, AlertCircle } from 'lucide-react';

interface AboutUsProps {
  navigate: (route: string) => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ navigate }) => {
  const { t } = useLanguage();

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-8">
      
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="badge badge-purple text-xs">Our Healthcare Mission</span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#1e1b4b]">
          About स्वास्थ्यसेतु (SwasthyaSetu)
        </h1>
        <p className="text-sm sm:text-base text-[#6b7280] max-w-2xl mx-auto">
          Built for the Healthcare Hackathon to bridge the geographic and economic divide separating rural families from qualified medical specialists.
        </p>
      </div>

      {/* Mission Card */}
      <div className="card bg-gradient-to-br from-[#faf5ff] to-white p-8 space-y-4 border-[#ddd6fe]">
        <h2 className="text-xl font-bold text-[#4c1d95] flex items-center gap-2">
          <HeartHandshake className="w-6 h-6 text-[#7c3aed]" />
          The Challenge in Rural Healthcare Access
        </h2>
        <p className="text-xs sm:text-sm text-[#4b5563] leading-relaxed">
          Over 65% of India’s population resides in rural areas, yet more than 75% of qualified medical doctors and specialist consultants operate in urban centres. Rural patients frequently incur massive travel expenses, forfeit daily wages, and wait in overcrowded clinics just to consult a doctor for seasonal viral infections, dermatological flare-ups, or basic lab report interpretations.
        </p>
        <p className="text-xs sm:text-sm text-[#4b5563] leading-relaxed">
          <strong>SwasthyaSetu</strong> solves this by offering a zero-friction, multilingual portal where patients describe symptoms through intuitive questionnaires, upload photographs of existing blood reports or old prescriptions, and connect with state-council-verified doctors.
        </p>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-[#1e1b4b]">Doctor-Connection, Not AI Diagnosis</h3>
          <p className="text-xs text-[#5b557d] leading-relaxed">
            We never generate automated algorithmic diagnoses. Certified medical reports are prepared, evaluated, and approved exclusively by licensed human medical doctors.
          </p>
        </div>

        <div className="card p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-[#1e1b4b]">Verified Credentials Only</h3>
          <p className="text-xs text-[#5b557d] leading-relaxed">
            Every physician profile requires verification of MBBS or postgraduate credentials and state medical council registration numbers before consulting.
          </p>
        </div>

        <div className="card p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-[#1e1b4b]">Strict Privacy & Security</h3>
          <p className="text-xs text-[#5b557d] leading-relaxed">
            Patient medical documents and test results reside in private object storage, safeguarded with PostgreSQL Row Level Security and short-lived signed links.
          </p>
        </div>
      </div>

      {/* Telemedicine Compliance Disclaimer */}
      <div className="bg-[#f5f3ff] border border-[#ddd6fe] rounded-2xl p-6 space-y-2 text-xs text-[#581c87]">
        <div className="flex items-center gap-2 font-bold text-sm text-[#4c1d95]">
          <AlertCircle className="w-4 h-4 text-[#7c3aed]" />
          <span>Telemedicine Guidelines & Emergency Protocols</span>
        </div>
        <p className="leading-relaxed text-[#4b5563]">
          SwasthyaSetu adheres to the Telemedicine Practice Guidelines issued jointly by the Ministry of Health and Family Welfare (MoHFW) and NITI Aayog. In case of acute emergencies, severe respiratory distress, or trauma, patients are directed to call 108 or report to the nearest primary health centre immediately.
        </p>
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { Database, Key, Server, Terminal, ShieldCheck, Mail, CheckCircle2, Copy } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

export const SetupGuide: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 py-8">
      
      {/* Title */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="badge badge-purple text-xs">Developer & Hackathon Documentation</span>
          {isSupabaseConfigured ? (
            <span className="badge badge-verified text-xs">Supabase Connected</span>
          ) : (
            <span className="badge bg-[#fef3c7] text-[#92400e] border border-[#fde68a] text-xs">
              Running in Local Interactive Demo Mode
            </span>
          )}
        </div>
        <h1 className="text-3xl font-black text-[#1e1b4b]">
          Backend & Supabase Setup Guide
        </h1>
        <p className="text-sm text-[#6b7280]">
          Follow these beginner-friendly steps to connect your SwasthyaSetu frontend to your real Supabase backend in under 5 minutes.
        </p>
      </div>

      {/* Step 1: Create Supabase Project */}
      <div className="card space-y-4 p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center font-extrabold">
            1
          </div>
          <div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">Create Free Supabase Project</h3>
            <p className="text-xs text-[#6b7280]">Supabase provides PostgreSQL, Auth, and Storage out of the box.</p>
          </div>
        </div>

        <ol className="list-decimal list-inside text-xs text-[#4b5563] space-y-2 leading-relaxed pl-2">
          <li>Go to <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-[#6d28d9] font-bold underline">supabase.com</a> and sign in with GitHub or your email.</li>
          <li>Click <strong>New Project</strong>.</li>
          <li>Choose a name (e.g. <code className="bg-[#f5f3ff] px-1.5 py-0.5 rounded text-[#581c87]">swasthyasetu-backend</code>) and create a strong database password.</li>
          <li>Select Region: <strong>South Asia (Mumbai)</strong> for optimal response times in India.</li>
        </ol>
      </div>

      {/* Step 2: Run SQL Migrations */}
      <div className="card space-y-4 p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center font-extrabold">
            2
          </div>
          <div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">Run SQL Migrations in Supabase SQL Editor</h3>
            <p className="text-xs text-[#6b7280]">Our migrations create all tables, RLS policies, storage buckets, and sample data.</p>
          </div>
        </div>

        <div className="text-xs text-[#4b5563] space-y-3 leading-relaxed">
          <p>
            In your Supabase project dashboard, open the <strong>SQL Editor</strong> tab on the left sidebar.
            Run the 5 migration files located in <code className="bg-[#f5f3ff] px-1.5 py-0.5 rounded text-[#581c87]">supabase/migrations/</code> in numerical order:
          </p>

          <div className="space-y-2">
            {[
              { file: '20261010000001_initial_schema.sql', desc: 'Creates profiles, doctor_profiles, patient_cases, documents, reports, ratings' },
              { file: '20261010000002_row_level_security.sql', desc: 'Enforces Row Level Security (RLS) policies for patient-doctor privacy' },
              { file: '20261010000003_storage_buckets.sql', desc: 'Sets up private storage buckets: patient-documents & doctor-qualifications' },
              { file: '20261010000004_triggers_and_functions.sql', desc: 'Automates user sync, status audits, and in-app notifications' },
              { file: '20261010000005_seed_data.sql', desc: 'Seeds verified doctors (Dr. Asha Verma, Dr. Rohan Mehta, etc.) and sample report' },
            ].map((m, idx) => (
              <div key={idx} className="flex items-start justify-between p-3 bg-[#faf8ff] border border-[#e9d5ff] rounded-xl">
                <div>
                  <span className="font-bold text-[#4c1d95] block">{m.file}</span>
                  <span className="text-[11px] text-[#6b7280]">{m.desc}</span>
                </div>
                <span className="badge badge-purple text-[10px]">Migration</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Step 3: Configure Environment Variables */}
      <div className="card space-y-4 p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center font-extrabold">
            3
          </div>
          <div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">Set Frontend Environment Variables</h3>
            <p className="text-xs text-[#6b7280]">Connect the React application using your public anon API key.</p>
          </div>
        </div>

        <div className="text-xs text-[#4b5563] space-y-3 leading-relaxed">
          <p>
            In your Supabase project dashboard, navigate to <strong>Project Settings → API</strong>. Copy your <strong>Project URL</strong> and <strong>anon / public key</strong>.
          </p>

          <div className="p-4 bg-[#1e1b4b] text-[#f5f3ff] rounded-2xl font-mono text-[11px] relative">
            <button
              onClick={() => copyToClipboard(`VITE_SUPABASE_URL=https://your-project-id.supabase.co\nVITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`, 'env')}
              className="absolute right-3 top-3 px-2 py-1 bg-white/20 hover:bg-white/30 rounded text-xs flex items-center gap-1"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedSection === 'env' ? 'Copied!' : 'Copy'}</span>
            </button>
            <p className="text-[#a78bfa] mb-2"># Create .env in project root:</p>
            <p>VITE_SUPABASE_URL=https://your-project-id.supabase.co</p>
            <p>VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</p>
          </div>

          <div className="p-3 bg-[#fef2f2] text-[#991b1b] rounded-xl text-xs flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-[#dc2626] shrink-0 mt-0.5" />
            <span>
              <strong>Crucial Security Rule:</strong> NEVER put your <code className="font-bold">service_role</code> secret key in the frontend <code className="font-bold">.env</code>. That key bypasses all RLS policies and belongs strictly on your server or Edge Functions.
            </span>
          </div>
        </div>
      </div>

      {/* Step 4: Configure Email Notifications (Resend) */}
      <div className="card space-y-4 p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center font-extrabold">
            4
          </div>
          <div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">Optional: Configure Resend for Report Emails</h3>
            <p className="text-xs text-[#6b7280]">Our Supabase Edge Function <code className="text-[#581c87]">send-report-email</code> dispatches emails when reports are released.</p>
          </div>
        </div>

        <ol className="list-decimal list-inside text-xs text-[#4b5563] space-y-2 leading-relaxed pl-2">
          <li>Create a free account on <a href="https://resend.com" target="_blank" rel="noreferrer" className="text-[#6d28d9] font-bold underline">resend.com</a> and generate an API key.</li>
          <li>In your terminal, deploy the Edge Function and set server secrets:</li>
        </ol>

        <div className="p-4 bg-[#1e1b4b] text-[#f5f3ff] rounded-2xl font-mono text-[11px]">
          <p className="text-[#a78bfa] mb-1"># Deploy edge function using Supabase CLI:</p>
          <p>npx supabase secrets set RESEND_API_KEY="re_your_api_key"</p>
          <p>npx supabase functions deploy send-report-email</p>
        </div>
      </div>

    </div>
  );
};

import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { EmergencyBanner } from '../components/EmergencyBanner';
import { 
  Stethoscope, 
  Search, 
  ShieldCheck, 
  FileText, 
  Lock, 
  HeartHandshake, 
  ArrowRight, 
  CheckCircle, 
  Users,
  Clock
} from 'lucide-react';

interface HomeProps {
  navigate: (route: string) => void;
}

export const Home: React.FC<HomeProps> = ({ navigate }) => {
  const { t } = useLanguage();
  const { user } = useAuth();

  return (
    <div className="space-y-16 py-8">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#4c1d95] via-[#6d28d9] to-[#7c3aed] text-white p-8 sm:p-12 md:p-16 shadow-xl">
        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-xs font-bold text-[#ede9fe] border border-white/20">
            <ShieldCheck className="w-4 h-4 text-[#34d399]" />
            <span>Telemedicine Platform for Rural Communities</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
            {t('heroTitle')}
          </h1>

          <p className="text-base sm:text-lg text-[#ddd6fe] leading-relaxed max-w-2xl">
            {t('heroSubtitle')}
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-4">
            <button
              onClick={() => navigate('triage')}
              className="btn-primary bg-white text-[#581c87] hover:bg-[#f5f3ff] hover:text-[#4c1d95] px-6 py-3.5 text-sm sm:text-base font-bold shadow-lg shadow-black/10"
            >
              <Stethoscope className="w-5 h-5 text-[#6d28d9]" />
              <span>{t('heroStartBtn')}</span>
            </button>

            <button
              onClick={() => navigate('doctors')}
              className="btn-secondary bg-white/10 text-white border-white/30 hover:bg-white/20 px-6 py-3.5 text-sm sm:text-base font-bold"
            >
              <Search className="w-5 h-5" />
              <span>{t('heroFindDocBtn')}</span>
            </button>
          </div>

          {/* Quick Stats Pill */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-3 gap-6 border-t border-white/15">
            <div>
              <p className="text-2xl sm:text-3xl font-black text-white">100%</p>
              <p className="text-xs text-[#c4b5fd]">Verified MBBS & Specialists</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-black text-white">हिंदी & EN</p>
              <p className="text-xs text-[#c4b5fd]">Multilingual Accessible</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-black text-white">&lt; 4 hrs</p>
              <p className="text-xs text-[#c4b5fd]">Average Consultation Turnaround</p>
            </div>
          </div>
        </div>

        {/* Decorative background glows */}
        <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-[#8b5cf6]/30 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute right-10 top-10 w-64 h-64 bg-[#ec4899]/15 rounded-full blur-2xl pointer-events-none"></div>
      </section>

      {/* Emergency Alert Banner */}
      <EmergencyBanner />

      {/* 4 Pillars Section */}
      <section className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1e1b4b]">
            Why Patients & Doctors Trust SwasthyaSetu
          </h2>
          <p className="text-sm text-[#6b7280]">
            A patient-first healthcare ecosystem built specifically to solve healthcare access in underserved areas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="card space-y-3 hover:border-[#c4b5fd] transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">{t('pillar1Title')}</h3>
            <p className="text-xs text-[#5b557d] leading-relaxed">{t('pillar1Desc')}</p>
          </div>

          <div className="card space-y-3 hover:border-[#c4b5fd] transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">{t('pillar2Title')}</h3>
            <p className="text-xs text-[#5b557d] leading-relaxed">{t('pillar2Desc')}</p>
          </div>

          <div className="card space-y-3 hover:border-[#c4b5fd] transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">{t('pillar3Title')}</h3>
            <p className="text-xs text-[#5b557d] leading-relaxed">{t('pillar3Desc')}</p>
          </div>

          <div className="card space-y-3 hover:border-[#c4b5fd] transition-colors">
            <div className="w-12 h-12 rounded-2xl bg-[#ede9fe] text-[#6d28d9] flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#1e1b4b]">{t('pillar4Title')}</h3>
            <p className="text-xs text-[#5b557d] leading-relaxed">{t('pillar4Desc')}</p>
          </div>

        </div>
      </section>

      {/* Quick Action Banner */}
      <section className="bg-[#faf5ff] border border-[#e9d5ff] rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <h3 className="text-xl sm:text-2xl font-black text-[#4c1d95]">
            Have an existing medical document or fever?
          </h3>
          <p className="text-xs sm:text-sm text-[#5b557d] leading-relaxed">
            Take our 2-minute symptom questionnaire, securely attach your existing blood tests or old prescriptions, and get a qualified doctor's review.
          </p>
        </div>

        <button
          onClick={() => navigate('triage')}
          className="btn-primary whitespace-nowrap shadow-md text-sm sm:text-base px-6 py-3"
        >
          <span>Begin Free Symptom Review</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </section>

    </div>
  );
};

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { authService, SignUpParams } from '../services/auth';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  signIn: (email: string, pass: string) => Promise<{ error: string | null }>;
  signUp: (params: SignUpParams) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  switchDemoRole: (role: UserRole) => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const refreshProfile = async () => {
    try {
      const u = await authService.getSessionUser();
      setUser(u);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshProfile();

    if (isSupabaseConfigured) {
      const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
        if (session?.user) {
          const profile = await authService.getCurrentProfile(session.user.id);
          setUser(profile);
        } else {
          setUser(null);
        }
        setLoading(false);
      });

      return () => {
        subscription.unsubscribe();
      };
    }
  }, []);

  const signIn = async (email: string, pass: string) => {
    setLoading(true);
    const { user: loggedIn, error } = await authService.signIn(email, pass);
    setUser(loggedIn);
    setLoading(false);
    return { error };
  };

  const signUp = async (params: SignUpParams) => {
    setLoading(true);
    const { user: registered, error } = await authService.signUp(params);
    setUser(registered);
    setLoading(false);
    return { error };
  };

  const signOut = async () => {
    setLoading(true);
    await authService.signOut();
    setUser(null);
    setLoading(false);
  };

  const switchDemoRole = (role: UserRole) => {
    if (role === 'doctor') {
      const doc: UserProfile = {
        id: '11111111-1111-1111-1111-111111111111',
        email: 'dr.asha.verma@swasthyasetu.org',
        full_name: 'Dr. Asha Verma',
        role: 'doctor',
        phone: '+91 98765 43210',
        preferred_language: 'hi',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      localStorage.setItem('swasthyasetu_mock_user', JSON.stringify(doc));
      setUser(doc);
    } else {
      const pat: UserProfile = {
        id: '99999999-9999-9999-9999-999999999999',
        email: 'ramesh.kumar@example.com',
        full_name: 'Ramesh Kumar (Demo Patient)',
        role: 'patient',
        phone: '+91 91234 56789',
        preferred_language: 'hi',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      localStorage.setItem('swasthyasetu_mock_user', JSON.stringify(pat));
      setUser(pat);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, switchDemoRole, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

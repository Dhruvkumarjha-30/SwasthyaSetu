import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { HowItWorks } from './pages/HowItWorks';
import { FindDoctors } from './pages/FindDoctors';
import { SymptomTriage } from './pages/SymptomTriage';
import { AboutUs } from './pages/AboutUs';
import { AuthPage } from './pages/AuthPage';
import { PatientDashboard } from './pages/PatientDashboard';
import { DoctorDashboard } from './pages/DoctorDashboard';
import { SetupGuide } from './pages/SetupGuide';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  
  // Hash-based simple router supporting browser back/forward and links
  const [route, setRoute] = useState<string>(() => {
    const hash = window.location.hash.replace('#/', '').replace('#', '');
    return hash || 'home';
  });

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '');
      setRoute(hash || 'home');
      window.scrollTo(0, 0);
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigate = (newRoute: string) => {
    window.location.hash = `#/${newRoute}`;
    setRoute(newRoute);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf8ff] text-[#1e1b4b]">
      {/* Top Navbar */}
      <Navbar currentRoute={route} navigate={navigate} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-6">
        {route === 'home' && <Home navigate={navigate} />}
        {route === 'how' && <HowItWorks navigate={navigate} />}
        {route === 'doctors' && <FindDoctors navigate={navigate} />}
        {route === 'triage' && <SymptomTriage navigate={navigate} />}
        {route === 'about' && <AboutUs navigate={navigate} />}
        {route === 'auth' && <AuthPage navigate={navigate} />}
        {route === 'patient-dashboard' && <PatientDashboard navigate={navigate} />}
        {route === 'doctor-dashboard' && <DoctorDashboard navigate={navigate} />}
        {route === 'setup' && <SetupGuide />}
      </main>

      {/* Global Footer */}
      <Footer />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
};

export default App;

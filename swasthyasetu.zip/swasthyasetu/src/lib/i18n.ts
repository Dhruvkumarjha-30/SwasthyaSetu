export type Language = 'en' | 'hi';

export const translations = {
  en: {
    brand: 'SwasthyaSetu',
    brandHindi: 'स्वास्थ्यसेतु',
    tagline: 'Rural Healthcare Access & Doctor Consultation',
    navHome: 'Home',
    navHow: 'How It Works',
    navDoctors: 'Find Doctors',
    navAbout: 'About Us',
    navCheck: 'Check Symptoms',
    navLogin: 'Login',
    navRegister: 'Register',
    navDashboard: 'Dashboard',
    navLogout: 'Sign Out',

    // Hero
    heroTitle: 'Your Health. Your Doctor. Within Reach.',
    heroSubtitle: 'Share your symptoms, upload your medical reports, and connect with qualified doctors from the comfort of your village or town.',
    heroStartBtn: 'Start Symptom Check',
    heroFindDocBtn: 'Find a Qualified Doctor',

    // Key Pillars
    pillar1Title: 'Bilingual & Accessible',
    pillar1Desc: 'Designed for rural India in both Hindi and English with simple, clear steps.',
    pillar2Title: 'Qualified Doctors Only',
    pillar2Desc: 'Every doctor profile is verified with their medical council registration.',
    pillar3Title: 'Official Medical Reports',
    pillar3Desc: 'Receive doctor-authored diagnosis summaries, prescriptions, and follow-up guidance.',
    pillar4Title: 'Private & Secure',
    pillar4Desc: 'Your health records and lab reports are encrypted in private medical storage.',

    // Emergency Warning
    emergencyTitle: 'Urgent Medical Attention Needed',
    emergencyMsg: 'If you are experiencing severe breathing difficulty, chest pain, uncontrollable bleeding, or loss of consciousness, please call emergency services immediately (108) or visit the nearest hospital. Do not wait for an online consultation.',
    call108: 'Call 108 Emergency',

    // Disclaimers
    disclaimerTitle: 'Medical Platform Notice',
    disclaimerText: 'SwasthyaSetu is a healthcare-access and doctor-connection platform, NOT an automated diagnostic system. All reports and prescriptions are authored and approved by qualified, licensed medical professionals.',

    // Doctor Discovery
    searchDoctorPlaceholder: 'Search by doctor name or specialty...',
    filterAllSpecialties: 'All Specialties',
    filterAllLanguages: 'All Languages',
    feeLabel: 'Consultation Fee',
    experienceLabel: 'Experience',
    verifiedBadge: 'Verified Medical Practitioner',
    pendingVerification: 'Verification Pending',
    consultDoctorBtn: 'Consult Doctor',
    noDoctorsFound: 'No doctors found matching your filter criteria.',

    // Symptom Triage Form
    triageTitle: 'Symptom Health Questionnaire',
    triageSubtitle: 'Answer simple questions to help your doctor understand your condition.',
    selectSymptoms: 'What symptoms are you experiencing?',
    symptomDuration: 'How long have you had these symptoms?',
    additionalNotes: 'Any other details or questions for the doctor?',
    additionalNotesPlaceholder: 'E.g., I also have mild shivering in the evening, blood sugar was normal last week...',
    uploadDocsTitle: 'Upload Medical Documents (Optional)',
    uploadDocsDesc: 'Upload recent blood tests, previous prescriptions, or X-rays (PDF, JPG, PNG up to 10MB).',
    chooseDoctorTitle: 'Select a Doctor',
    autoAssignDoctor: 'Auto-assign available doctor (Recommended for quickest review)',
    submitConsultationBtn: 'Submit Consultation Request',
    submitting: 'Submitting securely...',
    consentCheckbox: 'I agree to share my health details and documents with the chosen doctor for clinical review.',

    // Dashboards
    patientDashboard: 'Patient Health Portal',
    doctorDashboard: 'Doctor Clinical Workspace',
    activeCases: 'Active Consultations',
    pastCases: 'Completed Cases',
    viewReportBtn: 'View Medical Report',
    downloadReportBtn: 'Download Report',
    statusSubmitted: 'Submitted',
    statusAssigned: 'Doctor Assigned',
    statusUnderReview: 'Under Doctor Review',
    statusReportReady: 'Medical Report Ready',
    statusCompleted: 'Completed',

    // Doctor Report Authoring
    authorReportTitle: 'Prepare Medical Consultation Report',
    clinicalSummary: 'Clinical Summary & Observations',
    diagnosisNotes: 'Diagnosis / Clinical Assessment',
    prescriptions: 'Prescription & Dosages',
    addMedicineBtn: '+ Add Medicine',
    medicineName: 'Medicine Name & Strength',
    dosage: 'Dosage (e.g. 1 tab twice daily after food)',
    duration: 'Duration (e.g. 5 days)',
    dietLifestyleAdvice: 'Dietary & Lifestyle Advice',
    followUp: 'Follow-up Recommendation',
    saveDraftBtn: 'Save Draft',
    releaseToPatientBtn: 'Release Report to Patient',

    // Ratings
    rateDoctorTitle: 'Rate Your Consultation Experience',
    rateDoctorDesc: 'How satisfied were you with the doctor’s guidance and clarity?',
    submitRatingBtn: 'Submit Rating',
    ratingSuccess: 'Thank you for your rating! It helps other patients find trusted care.'
  },

  hi: {
    brand: 'स्वास्थ्यसेतु',
    brandHindi: 'स्वास्थ्यसेतु',
    tagline: 'ग्रामीण स्वास्थ्य सेवा और डॉक्टर परामर्श मंच',
    navHome: 'होम',
    navHow: 'यह कैसे काम करता है',
    navDoctors: 'डॉक्टर खोजें',
    navAbout: 'हमारे बारे में',
    navCheck: 'लक्षण जांचें',
    navLogin: 'लॉग इन',
    navRegister: 'पंजीकरण',
    navDashboard: 'डैशबोर्ड',
    navLogout: 'लॉग आउट',

    // Hero
    heroTitle: 'आपका स्वास्थ्य। आपका डॉक्टर। आपकी पहुंच में।',
    heroSubtitle: 'अपने लक्षण साझा करें, अपनी पुरानी दवाइयों या जांच की पर्ची अपलोड करें और अपने गांव या घर बैठे योग्य डॉक्टर से परामर्श लें।',
    heroStartBtn: 'लक्षण जांच शुरू करें',
    heroFindDocBtn: 'योग्य डॉक्टर खोजें',

    // Key Pillars
    pillar1Title: 'द्विभाषी और सरल',
    pillar1Desc: 'ग्रामीण भारत के लिए हिंदी और अंग्रेजी दोनों में अत्यंत सरल चरणों के साथ निर्मित।',
    pillar2Title: 'केवल सत्यापित डॉक्टर',
    pillar2Desc: 'प्रत्येक डॉक्टर के मेडिकल काउंसिल पंजीकरण की विधिवत जांच की जाती है।',
    pillar3Title: 'आधिकारिक मेडिकल रिपोर्ट',
    pillar3Desc: 'डॉक्टर द्वारा तैयार की गई प्रामाणिक रिपोर्ट, दवाइयों की पर्ची और परहेज की सलाह प्राप्त करें।',
    pillar4Title: 'निजी और सुरक्षित',
    pillar4Desc: 'आपकी जांच रिपोर्ट और स्वास्थ्य विवरण पूरी तरह सुरक्षित और गोपनीय रहते हैं।',

    // Emergency Warning
    emergencyTitle: 'आपातकालीन सूचना',
    emergencyMsg: 'यदि सांस लेने में भारी तकलीफ, सीने में तेज दर्द, अत्यधिक रक्तस्राव या बेहोशी जैसे गंभीर लक्षण हैं, तो कृपया तुरंत 108 पर कॉल करें या नजदीकी अस्पताल जाएं। ऑनलाइन परामर्श का इंतजार न करें।',
    call108: '108 आपातकालीन कॉल',

    // Disclaimers
    disclaimerTitle: 'चिकित्सा मंच सूचना',
    disclaimerText: 'स्वास्थ्यसेतु मरीजों को योग्य डॉक्टरों से जोड़ने का मंच है, यह कोई स्वचालित कंप्यूटर डायग्नोसिस प्रणाली नहीं है। सभी रिपोर्ट और सलाह प्रमाणित डॉक्टरों द्वारा ही दी जाती हैं।',

    // Doctor Discovery
    searchDoctorPlaceholder: 'डॉक्टर का नाम या विशेषज्ञता खोजें...',
    filterAllSpecialties: 'सभी विशेषज्ञता',
    filterAllLanguages: 'सभी भाषाएं',
    feeLabel: 'परामर्श शुल्क',
    experienceLabel: 'अनुभव',
    verifiedBadge: 'सत्यापित डॉक्टर',
    pendingVerification: 'सत्यापन प्रक्रियाधीन',
    consultDoctorBtn: 'डॉक्टर से परामर्श लें',
    noDoctorsFound: 'आपके चुने गए फ़िल्टर के अनुसार कोई डॉक्टर नहीं मिले।',

    // Symptom Triage Form
    triageTitle: 'स्वास्थ्य लक्षण प्रश्नावली',
    triageSubtitle: 'डॉक्टर को आपकी बीमारी समझने में मदद करने के लिए सरल प्रश्नों के उत्तर दें।',
    selectSymptoms: 'आपको क्या लक्षण महसूस हो रहे हैं?',
    symptomDuration: 'यह परेशानी कितने समय से है?',
    additionalNotes: 'डॉक्टर के लिए कोई अन्य जानकारी या प्रश्न?',
    additionalNotesPlaceholder: 'उदा. शाम को हल्का बुखार आता है, पिछले हफ्ते बीपी सामान्य था...',
    uploadDocsTitle: 'मेडिकल दस्तावेज अपलोड करें (वैकल्पिक)',
    uploadDocsDesc: 'हाल ही की खून की जांच, पुरानी पर्ची या एक्स-रे (पीडीएफ या फोटो, अधिकतम 10MB) अपलोड करें।',
    chooseDoctorTitle: 'डॉक्टर चुनें',
    autoAssignDoctor: 'उपलब्ध डॉक्टर को तुरंत सौंपें (तेज़ परामर्श के लिए अनुशंसित)',
    submitConsultationBtn: 'परामर्श अनुरोध भेजें',
    submitting: 'सुरक्षित रूप से भेजा जा रहा है...',
    consentCheckbox: 'मैं अपने स्वास्थ्य विवरण और जांच रिपोर्ट को चुने गए डॉक्टर के साथ साझा करने की सहमति देता/देती हूँ।',

    // Dashboards
    patientDashboard: 'रोगी स्वास्थ्य पोर्टल',
    doctorDashboard: 'डॉक्टर क्लिनिकल कार्यक्षेत्र',
    activeCases: 'सक्रिय परामर्श',
    pastCases: 'पूर्ण परामर्श',
    viewReportBtn: 'मेडिकल रिपोर्ट देखें',
    downloadReportBtn: 'रिपोर्ट डाउनलोड करें',
    statusSubmitted: 'जमा किया गया',
    statusAssigned: 'डॉक्टर नियुक्त',
    statusUnderReview: 'डॉक्टर समीक्षा जारी है',
    statusReportReady: 'मेडिकल रिपोर्ट तैयार है',
    statusCompleted: 'पूर्ण हुआ',

    // Doctor Report Authoring
    authorReportTitle: 'चिकित्सा परामर्श रिपोर्ट तैयार करें',
    clinicalSummary: 'क्लिनिकल सारांश और अवलोकन',
    diagnosisNotes: 'निदान / रोग का आकलन',
    prescriptions: 'दवाइयां और खुराक',
    addMedicineBtn: '+ दवा जोड़ें',
    medicineName: 'दवा का नाम और क्षमता',
    dosage: 'खुराक (उदा. दिन में 2 बार भोजन के बाद)',
    duration: 'अवधि (उदा. 5 दिन)',
    dietLifestyleAdvice: 'खान-पान और परहेज की सलाह',
    followUp: 'आगे की जांच या फॉलो-अप सलाह',
    saveDraftBtn: 'ड्राफ्ट सहेजें',
    releaseToPatientBtn: 'रोगी को रिपोर्ट जारी करें',

    // Ratings
    rateDoctorTitle: 'परामर्श अनुभव का मूल्यांकन करें',
    rateDoctorDesc: 'डॉक्टर की सलाह और मार्गदर्शन से आप कितने संतुष्ट हैं?',
    submitRatingBtn: 'रेटिंग जमा करें',
    ratingSuccess: 'मूल्यांकन के लिए धन्यवाद! इससे अन्य मरीजों को भी सही डॉक्टर चुनने में मदद मिलती है।'
  }
};

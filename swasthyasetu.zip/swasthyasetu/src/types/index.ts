export type UserRole = 'patient' | 'doctor' | 'admin';

export type CaseStatus = 
  | 'draft'
  | 'submitted'
  | 'awaiting_assignment'
  | 'assigned'
  | 'under_review'
  | 'report_ready'
  | 'completed'
  | 'cancelled';

export type DoctorVerificationStatus = 'pending' | 'verified' | 'rejected';

export type ReportStatus = 'draft' | 'submitted' | 'released';

export type NotificationType = 'info' | 'case_update' | 'report_ready' | 'urgent' | 'assignment';

export type MedicalDocumentType = 
  | 'blood_report'
  | 'prescription'
  | 'radiology_scan'
  | 'discharge_summary'
  | 'other';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone?: string | null;
  avatar_url?: string | null;
  preferred_language: 'en' | 'hi';
  created_at: string;
  updated_at: string;
}

export interface DoctorProfile {
  id: string;
  full_name?: string;
  email?: string;
  specialty: string;
  qualifications: string;
  experience_years: number;
  languages: string[];
  clinic_location: string;
  consultation_fee: number;
  bio?: string | null;
  registration_number?: string | null;
  verification_status: DoctorVerificationStatus;
  is_available: boolean;
  average_rating?: number;
  review_count?: number;
  created_at: string;
  updated_at: string;
}

export interface PatientCase {
  id: string;
  patient_id: string;
  assigned_doctor_id?: string | null;
  status: CaseStatus;
  chief_complaint: string;
  symptoms: string[];
  duration?: string | null;
  questionnaire_responses: Record<string, string | string[]>;
  emergency_flag: boolean;
  patient_notes?: string | null;
  created_at: string;
  updated_at: string;
  doctor?: DoctorProfile | null;
  patient?: UserProfile | null;
  documents?: MedicalDocument[];
}

export interface MedicalDocument {
  id: string;
  case_id?: string | null;
  patient_id: string;
  document_name: string;
  storage_path: string;
  file_size: number;
  mime_type: string;
  document_type: MedicalDocumentType;
  uploaded_at: string;
  download_url?: string;
}

export interface PrescriptionItem {
  medicine: string;
  dosage: string;
  duration: string;
  instructions?: string;
}

export interface DoctorReport {
  id: string;
  case_id: string;
  doctor_id: string;
  patient_id: string;
  clinical_summary: string;
  diagnosis_notes: string;
  prescriptions: PrescriptionItem[];
  dietary_lifestyle_advice?: string | null;
  follow_up_recommendations?: string | null;
  is_emergency_referral: boolean;
  status: ReportStatus;
  version: number;
  created_at: string;
  updated_at: string;
  released_at?: string | null;
  doctor?: DoctorProfile | null;
}

export interface DoctorRating {
  id: string;
  case_id: string;
  patient_id: string;
  doctor_id: string;
  rating: number;
  review_text?: string | null;
  created_at: string;
  patient_name?: string;
}

export interface InAppNotification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  link?: string | null;
  is_read: boolean;
  created_at: string;
}

export interface CaseStatusHistoryItem {
  id: string;
  case_id: string;
  changed_by?: string | null;
  old_status: CaseStatus;
  new_status: CaseStatus;
  comment?: string | null;
  created_at: string;
}

// Supabase Edge Function: send-report-email
// Description: Secure server-side email delivery when a doctor releases a medical report.
// Invokes Resend API without exposing credentials to the client browser.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

interface ReportEmailPayload {
  reportId: string;
  patientEmail: string;
  patientName: string;
  doctorName: string;
  appUrl?: string;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing Authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body: ReportEmailPayload = await req.json();
    const { reportId, patientEmail, patientName, doctorName, appUrl } = body;

    if (!reportId || !patientEmail || !patientName || !doctorName) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: reportId, patientEmail, patientName, doctorName" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Server-side secret retrieval
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const senderEmail = Deno.env.get("NOTIFICATION_FROM_EMAIL") || "SwasthyaSetu <notifications@swasthyasetu.org>";
    const portalUrl = appUrl || Deno.env.get("APP_URL") || "https://swasthyasetu.org";

    if (!resendApiKey) {
      console.warn("[send-report-email] RESEND_API_KEY is not configured in Supabase secrets.");
      return new Response(
        JSON.stringify({
          success: false,
          configured: false,
          message: "Email provider not configured. Report is released and visible via in-app notification.",
          timestamp: new Date().toISOString()
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Secure email template (NO sensitive medical findings or diagnoses sent over plain email)
    const emailHtml = `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background-color: #fdfcff; border: 1px solid #e9d5ff; border-radius: 16px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #581c87 0%, #7c3aed 100%); padding: 32px 24px; text-align: center; color: white;">
          <h1 style="margin: 0; font-size: 26px; font-weight: 700;">स्वास्थ्यसेतु • SwasthyaSetu</h1>
          <p style="margin: 6px 0 0 0; font-size: 15px; opacity: 0.9;">Rural Healthcare & Doctor Consultation Access</p>
        </div>
        
        <div style="padding: 32px 24px; color: #1e1b4b; line-height: 1.6;">
          <h2 style="margin-top: 0; color: #581c87; font-size: 20px;">Namaste, ${escapeHtml(patientName)}</h2>
          <p>We are pleased to inform you that <strong>Dr. ${escapeHtml(doctorName)}</strong> has carefully reviewed your symptom consultation request and has prepared your official medical report.</p>
          
          <div style="background-color: #f5f3ff; border-left: 4px solid #7c3aed; padding: 16px; border-radius: 8px; margin: 24px 0;">
            <p style="margin: 0; font-weight: 600; color: #4c1d95;">Your Privacy & Medical Confidentiality</p>
            <p style="margin: 6px 0 0 0; font-size: 14px; color: #4b5563;">
              To protect your private health information, medical diagnoses and prescription details are not included in this email. You can view and download your full report by logging into your secure patient portal.
            </p>
          </div>

          <div style="text-align: center; margin: 32px 0;">
            <a href="${escapeHtml(portalUrl)}/#/patient-dashboard?report_id=${encodeURIComponent(reportId)}" 
               style="background-color: #7c3aed; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 12px; font-weight: 600; display: inline-block; box-shadow: 0 4px 12px rgba(124, 58, 237, 0.3);">
              View Your Medical Report
            </a>
          </div>

          <p style="font-size: 13px; color: #6b7280; text-align: center;">
            If you did not request this consultation or suspect unauthorized access, please contact helpdesk@swasthyasetu.org.
          </p>
        </div>

        <div style="background-color: #f3e8ff; padding: 16px; text-align: center; font-size: 12px; color: #6b21a8; border-top: 1px solid #e9d5ff;">
          SwasthyaSetu Platform • Empowering Underserved Communities with Quality Healthcare Access
        </div>
      </div>
    `;

    // Invoke Resend API securely
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: senderEmail,
        to: [patientEmail],
        subject: `[SwasthyaSetu] Your Medical Report from Dr. ${doctorName} is Ready`,
        html: emailHtml,
      }),
    });

    const resendResult = await resendResponse.json();

    if (!resendResponse.ok) {
      console.error("[send-report-email] Resend provider returned error:", resendResult);
      return new Response(
        JSON.stringify({
          success: false,
          error: resendResult.message || "Failed to deliver email through provider",
          details: resendResult
        }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        messageId: resendResult.id,
        deliveredTo: patientEmail,
        timestamp: new Date().toISOString()
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err: any) {
    console.error("[send-report-email] Unexpected error:", err);
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

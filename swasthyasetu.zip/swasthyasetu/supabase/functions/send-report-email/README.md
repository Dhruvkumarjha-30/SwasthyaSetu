# Supabase Edge Function: `send-report-email`

This Edge Function securely handles automated email delivery when a doctor submits and releases an official medical report to a patient.

## Security Guarantees

1. **No Frontend Leaks**: Email provider keys (e.g. Resend) are never embedded in React frontend code or client-side JavaScript.
2. **Patient Privacy Protected**: To safeguard sensitive patient health data, explicit diagnoses and drug prescriptions are **never** included in plain-text notification emails. Patients receive a secure link to authenticate and access their report in their private dashboard.
3. **Decoupled Architecture**: Email failures never revert or corrupt the medical report database transaction.
4. **Authenticity**: Only authenticated doctors releasing a report can trigger this function.

## How to Deploy to Supabase

1. Install the Supabase CLI if you have not already:
   ```bash
   npm install -g supabase
   ```

2. Link your local project to your Supabase cloud project:
   ```bash
   npx supabase login
   npx supabase link --project-ref your-supabase-project-id
   ```

3. Configure your server-side secrets in Supabase (obtain a free API key at [resend.com](https://resend.com)):
   ```bash
   npx supabase secrets set RESEND_API_KEY="re_123456789abcdef"
   npx supabase secrets set NOTIFICATION_FROM_EMAIL="SwasthyaSetu <onboarding@resend.dev>"
   npx supabase secrets set APP_URL="https://your-frontend-domain.com"
   ```

4. Deploy the Edge Function:
   ```bash
   npx supabase functions deploy send-report-email
   ```

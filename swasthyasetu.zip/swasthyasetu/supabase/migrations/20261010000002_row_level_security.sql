-- Migration: 20261010000002_row_level_security.sql
-- Project: SwasthyaSetu (स्वास्थ्यसेतु)
-- Description: Row Level Security (RLS) policies enforcing patient-doctor separation, least privilege, and report access control.

-- Enable Row Level Security on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medical_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.case_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.in_app_notifications ENABLE ROW LEVEL SECURITY;

-- Helper function: Check if current authenticated user has doctor role
CREATE OR REPLACE FUNCTION public.is_doctor()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'doctor'
    );
$$;

-- Helper function: Check if current doctor is verified
CREATE OR REPLACE FUNCTION public.is_verified_doctor()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.doctor_profiles
        WHERE id = auth.uid() AND verification_status = 'verified'
    );
$$;

-- Helper function: Check if current user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'
    );
$$;

-- ============================================================================
-- 1. PROFILES POLICIES
-- ============================================================================

-- Users can read their own profile
CREATE POLICY "Users can read own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

-- Public/Patients can read doctor basic profiles
CREATE POLICY "Anyone can view doctor profiles basic info"
    ON public.profiles FOR SELECT
    USING (role = 'doctor');

-- Assigned doctors can read the patient's basic profile
CREATE POLICY "Assigned doctors can view patient profiles"
    ON public.profiles FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.patient_id = profiles.id
            AND patient_cases.assigned_doctor_id = auth.uid()
        )
    );

-- Users can update their own non-sensitive profile fields
CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Profiles are inserted by trigger or matching auth.uid()
CREATE POLICY "Users can insert own profile"
    ON public.profiles FOR INSERT
    WITH CHECK (auth.uid() = id);


-- ============================================================================
-- 2. DOCTOR PROFILES POLICIES
-- ============================================================================

-- Verified doctors can be seen by everyone (authenticated or public)
CREATE POLICY "Public can view verified doctors"
    ON public.doctor_profiles FOR SELECT
    USING (verification_status = 'verified');

-- Doctors can see their own profile regardless of verification state
CREATE POLICY "Doctors can view own doctor profile"
    ON public.doctor_profiles FOR SELECT
    USING (auth.uid() = id);

-- Doctors can update their own profile details (bio, fee, languages, etc.)
CREATE POLICY "Doctors can update own doctor profile"
    ON public.doctor_profiles FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Doctor profile initial insertion
CREATE POLICY "Doctors can insert own doctor profile"
    ON public.doctor_profiles FOR INSERT
    WITH CHECK (auth.uid() = id);


-- ============================================================================
-- 3. DOCTOR QUALIFICATION DOCUMENTS POLICIES
-- ============================================================================

-- Doctors can view their own qualification documents
CREATE POLICY "Doctors can view own documents"
    ON public.doctor_documents FOR SELECT
    USING (auth.uid() = doctor_id);

-- Doctors can upload their own qualification documents
CREATE POLICY "Doctors can upload own documents"
    ON public.doctor_documents FOR INSERT
    WITH CHECK (auth.uid() = doctor_id);

-- Only admins can update verification status of doctor documents
CREATE POLICY "Admins can manage doctor documents"
    ON public.doctor_documents FOR ALL
    USING (public.is_admin());


-- ============================================================================
-- 4. PATIENT CASES POLICIES
-- ============================================================================

-- Patients can view their own cases
CREATE POLICY "Patients can view own cases"
    ON public.patient_cases FOR SELECT
    USING (auth.uid() = patient_id);

-- Assigned doctors can view their assigned cases
CREATE POLICY "Doctors can view assigned cases"
    ON public.patient_cases FOR SELECT
    USING (auth.uid() = assigned_doctor_id);

-- Verified doctors can view open/unassigned cases awaiting assignment
CREATE POLICY "Verified doctors can view awaiting cases"
    ON public.patient_cases FOR SELECT
    USING (
        public.is_verified_doctor() AND
        (status IN ('submitted', 'awaiting_assignment') AND assigned_doctor_id IS NULL)
    );

-- Patients can create their own cases
CREATE POLICY "Patients can insert own cases"
    ON public.patient_cases FOR INSERT
    WITH CHECK (auth.uid() = patient_id);

-- Patients can update their cases while in draft or cancel them
CREATE POLICY "Patients can update own pending cases"
    ON public.patient_cases FOR UPDATE
    USING (auth.uid() = patient_id)
    WITH CHECK (auth.uid() = patient_id);

-- Assigned doctors can update status of assigned cases (e.g., under_review, report_ready, completed)
CREATE POLICY "Assigned doctors can update case status"
    ON public.patient_cases FOR UPDATE
    USING (auth.uid() = assigned_doctor_id)
    WITH CHECK (auth.uid() = assigned_doctor_id);

-- Verified doctors can accept/claim an unassigned case
CREATE POLICY "Verified doctors can accept unassigned cases"
    ON public.patient_cases FOR UPDATE
    USING (
        public.is_verified_doctor() AND
        assigned_doctor_id IS NULL AND
        status IN ('submitted', 'awaiting_assignment')
    )
    WITH CHECK (
        assigned_doctor_id = auth.uid()
    );


-- ============================================================================
-- 5. MEDICAL DOCUMENTS POLICIES
-- ============================================================================

-- Patients can view metadata for their own medical documents
CREATE POLICY "Patients can view own medical documents"
    ON public.medical_documents FOR SELECT
    USING (auth.uid() = patient_id);

-- Assigned doctors can view documents for cases assigned to them
CREATE POLICY "Doctors can view case medical documents"
    ON public.medical_documents FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.id = medical_documents.case_id
            AND patient_cases.assigned_doctor_id = auth.uid()
        )
    );

-- Patients can insert document metadata for their own cases
CREATE POLICY "Patients can insert own medical documents"
    ON public.medical_documents FOR INSERT
    WITH CHECK (auth.uid() = patient_id);

-- Patients can delete documents before consultation completion
CREATE POLICY "Patients can delete own medical documents"
    ON public.medical_documents FOR DELETE
    USING (auth.uid() = patient_id);


-- ============================================================================
-- 6. DOCTOR REPORTS POLICIES
-- ============================================================================

-- Authoring doctor can view their draft and released reports
CREATE POLICY "Doctors can view own authored reports"
    ON public.doctor_reports FOR SELECT
    USING (auth.uid() = doctor_id);

-- Patients can view reports ONLY when status is 'released' and it belongs to them
CREATE POLICY "Patients can view released reports"
    ON public.doctor_reports FOR SELECT
    USING (
        auth.uid() = patient_id AND
        status = 'released'
    );

-- Assigned doctors can insert reports for their cases
CREATE POLICY "Doctors can insert reports for assigned cases"
    ON public.doctor_reports FOR INSERT
    WITH CHECK (
        auth.uid() = doctor_id AND
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.id = doctor_reports.case_id
            AND patient_cases.assigned_doctor_id = auth.uid()
        )
    );

-- Doctors can update reports while status is 'draft'
CREATE POLICY "Doctors can update draft reports"
    ON public.doctor_reports FOR UPDATE
    USING (
        auth.uid() = doctor_id AND
        status = 'draft'
    )
    WITH CHECK (
        auth.uid() = doctor_id
    );


-- ============================================================================
-- 7. DOCTOR RATINGS POLICIES
-- ============================================================================

-- Ratings are publicly visible for verified doctors
CREATE POLICY "Public can view doctor ratings"
    ON public.doctor_ratings FOR SELECT
    USING (true);

-- Only eligible patients can submit a rating:
-- 1. Must be the patient who created the case
-- 2. Case must be 'report_ready' or 'completed'
-- 3. Doctor must have been the assigned doctor
CREATE POLICY "Eligible patients can submit ratings"
    ON public.doctor_ratings FOR INSERT
    WITH CHECK (
        auth.uid() = patient_id AND
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.id = doctor_ratings.case_id
            AND patient_cases.patient_id = auth.uid()
            AND patient_cases.assigned_doctor_id = doctor_ratings.doctor_id
            AND patient_cases.status IN ('report_ready', 'completed')
        )
    );


-- ============================================================================
-- 8. IN-APP NOTIFICATIONS POLICIES
-- ============================================================================

-- Users can view their own notifications
CREATE POLICY "Users can view own notifications"
    ON public.in_app_notifications FOR SELECT
    USING (auth.uid() = user_id);

-- Users can update (mark read) their own notifications
CREATE POLICY "Users can update own notifications"
    ON public.in_app_notifications FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);


-- ============================================================================
-- 9. CASE STATUS HISTORY POLICIES
-- ============================================================================

-- Patient can view status history of their own case
CREATE POLICY "Patients can view own case history"
    ON public.case_status_history FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.id = case_status_history.case_id
            AND patient_cases.patient_id = auth.uid()
        )
    );

-- Doctor can view status history of assigned case
CREATE POLICY "Doctors can view assigned case history"
    ON public.case_status_history FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.patient_cases
            WHERE patient_cases.id = case_status_history.case_id
            AND patient_cases.assigned_doctor_id = auth.uid()
        )
    );

-- Migration: 20261010000003_storage_buckets.sql
-- Project: SwasthyaSetu (स्वास्थ्यसेतु)
-- Description: Private Supabase Storage bucket definitions and secure access policies for medical documents.

-- 1. Create Private Storage Buckets
-- Note: inserting into storage.buckets is supported in Supabase migrations.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
    (
        'patient-documents',
        'patient-documents',
        false, -- Strictly PRIVATE, no public URL access
        10485760, -- 10 MB limit
        ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/webp']
    ),
    (
        'doctor-qualifications',
        'doctor-qualifications',
        false, -- Strictly PRIVATE
        15728640, -- 15 MB limit
        ARRAY['application/pdf', 'image/jpeg', 'image/png']
    )
ON CONFLICT (id) DO UPDATE SET
    public = EXCLUDED.public,
    file_size_limit = EXCLUDED.file_size_limit,
    allowed_mime_types = EXCLUDED.allowed_mime_types;

-- ============================================================================
-- 2. STORAGE OBJECT POLICIES FOR PATIENT DOCUMENTS
-- ============================================================================

-- A patient can upload files into their own patient folder: patient-documents/{patient_id}/*
CREATE POLICY "Patients can upload own medical documents"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'patient-documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

-- A patient can read / download their own files
CREATE POLICY "Patients can download own medical documents"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'patient-documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

-- An assigned doctor can download documents for their assigned patient cases
CREATE POLICY "Assigned doctors can view patient documents"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'patient-documents' AND
    EXISTS (
        SELECT 1 FROM public.medical_documents md
        JOIN public.patient_cases pc ON pc.id = md.case_id
        WHERE md.storage_path = name
        AND pc.assigned_doctor_id = auth.uid()
    )
);

-- A patient can delete their own documents
CREATE POLICY "Patients can delete own medical documents"
ON storage.objects FOR DELETE
TO authenticated
USING (
    bucket_id = 'patient-documents' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

-- ============================================================================
-- 3. STORAGE OBJECT POLICIES FOR DOCTOR QUALIFICATIONS
-- ============================================================================

-- A doctor can upload qualification documents into: doctor-qualifications/{doctor_id}/*
CREATE POLICY "Doctors can upload qualification documents"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'doctor-qualifications' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

-- A doctor can download their own qualification documents
CREATE POLICY "Doctors can download own qualification documents"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'doctor-qualifications' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

-- Admins can view all doctor qualification documents
CREATE POLICY "Admins can view doctor qualification documents"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'doctor-qualifications' AND
    EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'
    )
);

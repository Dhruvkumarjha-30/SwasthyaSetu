-- Migration: 20261010000001_initial_schema.sql
-- Project: SwasthyaSetu (स्वास्थ्यसेतु)
-- Description: Core schema for profiles, doctor profiles, cases, documents, reports, ratings, and notifications.

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. User Profiles table (tied to Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('patient', 'doctor', 'admin')),
    phone TEXT,
    avatar_url TEXT,
    preferred_language TEXT DEFAULT 'en' CHECK (preferred_language IN ('en', 'hi')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Doctor Profiles table (extends user profiles for doctors)
CREATE TABLE IF NOT EXISTS public.doctor_profiles (
    id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
    specialty TEXT NOT NULL,
    qualifications TEXT NOT NULL,
    experience_years INTEGER NOT NULL DEFAULT 0 CHECK (experience_years >= 0),
    languages TEXT[] NOT NULL DEFAULT ARRAY['Hindi', 'English'],
    clinic_location TEXT NOT NULL,
    consultation_fee INTEGER NOT NULL DEFAULT 0 CHECK (consultation_fee >= 0),
    bio TEXT,
    registration_number TEXT,
    verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
    is_available BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Doctor Qualification Documents (for verification by administrators)
CREATE TABLE IF NOT EXISTS public.doctor_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doctor_id UUID NOT NULL REFERENCES public.doctor_profiles(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL CHECK (document_type IN ('medical_degree', 'state_council_registration', 'id_proof', 'other')),
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    mime_type TEXT NOT NULL,
    verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
    reviewed_at TIMESTAMPTZ,
    reviewed_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Patient Cases (Consultation Requests & Symptom Questionnaires)
CREATE TABLE IF NOT EXISTS public.patient_cases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    assigned_doctor_id UUID REFERENCES public.doctor_profiles(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'submitted' CHECK (
        status IN (
            'draft',
            'submitted',
            'awaiting_assignment',
            'assigned',
            'under_review',
            'report_ready',
            'completed',
            'cancelled'
        )
    ),
    chief_complaint TEXT NOT NULL,
    symptoms TEXT[] NOT NULL DEFAULT '{}',
    duration TEXT,
    questionnaire_responses JSONB NOT NULL DEFAULT '{}'::jsonb,
    emergency_flag BOOLEAN NOT NULL DEFAULT false,
    patient_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Medical Documents Metadata (Private Storage references)
CREATE TABLE IF NOT EXISTS public.medical_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID REFERENCES public.patient_cases(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    document_name TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    file_size INTEGER NOT NULL CHECK (file_size > 0),
    mime_type TEXT NOT NULL,
    document_type TEXT NOT NULL CHECK (
        document_type IN ('blood_report', 'prescription', 'radiology_scan', 'discharge_summary', 'other')
    ),
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Doctor-Authored Medical Reports
CREATE TABLE IF NOT EXISTS public.doctor_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES public.patient_cases(id) ON DELETE CASCADE,
    doctor_id UUID NOT NULL REFERENCES public.doctor_profiles(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    clinical_summary TEXT NOT NULL,
    diagnosis_notes TEXT NOT NULL,
    prescriptions JSONB NOT NULL DEFAULT '[]'::jsonb,
    dietary_lifestyle_advice TEXT,
    follow_up_recommendations TEXT,
    is_emergency_referral BOOLEAN NOT NULL DEFAULT false,
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'released')),
    version INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    released_at TIMESTAMPTZ
);

-- 7. Consultation Status History
CREATE TABLE IF NOT EXISTS public.case_status_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES public.patient_cases(id) ON DELETE CASCADE,
    changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    old_status TEXT NOT NULL,
    new_status TEXT NOT NULL,
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. Doctor Ratings and Reviews (Restricted to completed eligible consultations)
CREATE TABLE IF NOT EXISTS public.doctor_ratings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES public.patient_cases(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    doctor_id UUID NOT NULL REFERENCES public.doctor_profiles(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT unique_patient_case_rating UNIQUE (case_id, patient_id)
);

-- 9. In-App Notifications
CREATE TABLE IF NOT EXISTS public.in_app_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'info' CHECK (
        type IN ('info', 'case_update', 'report_ready', 'urgent', 'assignment')
    ),
    link TEXT,
    is_read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for performance and quick lookups
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_doctor_profiles_specialty ON public.doctor_profiles(specialty);
CREATE INDEX IF NOT EXISTS idx_doctor_profiles_verification ON public.doctor_profiles(verification_status);
CREATE INDEX IF NOT EXISTS idx_patient_cases_patient_id ON public.patient_cases(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_cases_doctor_id ON public.patient_cases(assigned_doctor_id);
CREATE INDEX IF NOT EXISTS idx_patient_cases_status ON public.patient_cases(status);
CREATE INDEX IF NOT EXISTS idx_medical_documents_case_id ON public.medical_documents(case_id);
CREATE INDEX IF NOT EXISTS idx_medical_documents_patient_id ON public.medical_documents(patient_id);
CREATE INDEX IF NOT EXISTS idx_doctor_reports_case_id ON public.doctor_reports(case_id);
CREATE INDEX IF NOT EXISTS idx_doctor_reports_doctor_id ON public.doctor_reports(doctor_id);
CREATE INDEX IF NOT EXISTS idx_doctor_reports_patient_id ON public.doctor_reports(patient_id);
CREATE INDEX IF NOT EXISTS idx_doctor_ratings_doctor_id ON public.doctor_ratings(doctor_id);
CREATE INDEX IF NOT EXISTS idx_in_app_notifications_user_id ON public.in_app_notifications(user_id);

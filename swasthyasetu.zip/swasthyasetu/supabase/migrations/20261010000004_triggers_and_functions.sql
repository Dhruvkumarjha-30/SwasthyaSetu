-- Migration: 20261010000004_triggers_and_functions.sql
-- Project: SwasthyaSetu (स्वास्थ्यसेतु)
-- Description: Automated triggers for secure user provisioning, role protection, audit trails, and in-app notifications.

-- 1. Handle New User Provisioning from Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    user_role TEXT;
    user_name TEXT;
    user_phone TEXT;
BEGIN
    user_role := COALESCE(NEW.raw_user_meta_data->>'role', 'patient');
    -- Safety check: don't allow arbitrary roles
    IF user_role NOT IN ('patient', 'doctor') THEN
        user_role := 'patient';
    END IF;

    user_name := COALESCE(NEW.raw_user_meta_data->>'full_name', 'User ' || substr(NEW.id::text, 1, 6));
    user_phone := NEW.raw_user_meta_data->>'phone';

    -- Insert into public.profiles
    INSERT INTO public.profiles (id, email, full_name, role, phone)
    VALUES (NEW.id, NEW.email, user_name, user_role, user_phone)
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        full_name = EXCLUDED.full_name;

    -- If the user registered as a doctor, provision a pending doctor profile
    IF user_role = 'doctor' THEN
        INSERT INTO public.doctor_profiles (
            id,
            specialty,
            qualifications,
            experience_years,
            languages,
            clinic_location,
            consultation_fee,
            bio,
            verification_status,
            is_available
        ) VALUES (
            NEW.id,
            COALESCE(NEW.raw_user_meta_data->>'specialty', 'General Physician'),
            COALESCE(NEW.raw_user_meta_data->>'qualifications', 'MBBS'),
            COALESCE((NEW.raw_user_meta_data->>'experience_years')::INTEGER, 1),
            ARRAY['Hindi', 'English'],
            COALESCE(NEW.raw_user_meta_data->>'clinic_location', 'Primary Health Centre'),
            COALESCE((NEW.raw_user_meta_data->>'consultation_fee')::INTEGER, 0),
            COALESCE(NEW.raw_user_meta_data->>'bio', 'Healthcare professional serving rural communities.'),
            'pending', -- Must start as pending, requires admin verification!
            true
        )
        ON CONFLICT (id) DO NOTHING;
    END IF;

    -- Welcome notification
    INSERT INTO public.in_app_notifications (user_id, title, message, type)
    VALUES (
        NEW.id,
        'Welcome to SwasthyaSetu!',
        'Your account has been created. Connect with qualified doctors and manage your medical health securely.',
        'info'
    );

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- 2. Prevent Privilege Escalation
-- Prevent users from changing their own role in public.profiles
CREATE OR REPLACE FUNCTION public.check_profile_updates()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    -- Only admin can change a user's role
    IF OLD.role <> NEW.role AND NOT public.is_admin() THEN
        RAISE EXCEPTION 'Unauthorized: You cannot change user role.';
    END IF;
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_profile_security ON public.profiles;
CREATE TRIGGER enforce_profile_security
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.check_profile_updates();


-- Prevent doctors from self-verifying in doctor_profiles
CREATE OR REPLACE FUNCTION public.check_doctor_verification_update()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    -- Only an admin can change verification_status
    IF OLD.verification_status <> NEW.verification_status AND NOT public.is_admin() THEN
        RAISE EXCEPTION 'Unauthorized: Doctor verification can only be approved by system administrators.';
    END IF;
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_doctor_verification_security ON public.doctor_profiles;
CREATE TRIGGER enforce_doctor_verification_security
    BEFORE UPDATE ON public.doctor_profiles
    FOR EACH ROW EXECUTE FUNCTION public.check_doctor_verification_update();


-- 3. Case Status Transition Logging and In-App Notifications
CREATE OR REPLACE FUNCTION public.handle_case_status_change()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    patient_msg TEXT;
    doc_name TEXT;
BEGIN
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        -- Record in audit history
        INSERT INTO public.case_status_history (case_id, changed_by, old_status, new_status, comment)
        VALUES (NEW.id, auth.uid(), OLD.status, NEW.status, 'Status changed to ' || NEW.status);

        -- Lookup doctor name if assigned
        IF NEW.assigned_doctor_id IS NOT NULL THEN
            SELECT full_name INTO doc_name FROM public.profiles WHERE id = NEW.assigned_doctor_id;
        END IF;

        -- Prepare friendly notification message for patient
        IF NEW.status = 'assigned' THEN
            patient_msg := 'Your consultation case has been assigned to Dr. ' || COALESCE(doc_name, 'a doctor') || '. They will review your medical details shortly.';
            INSERT INTO public.in_app_notifications (user_id, title, message, type, link)
            VALUES (NEW.patient_id, 'Doctor Assigned', patient_msg, 'assignment', '/patient-dashboard');

            -- Notify assigned doctor as well
            INSERT INTO public.in_app_notifications (user_id, title, message, type, link)
            VALUES (NEW.assigned_doctor_id, 'New Patient Case Assigned', 'A new patient consultation has been assigned to you. Please review symptoms and documents.', 'case_update', '/doctor-dashboard');

        ELSIF NEW.status = 'under_review' THEN
            patient_msg := 'Dr. ' || COALESCE(doc_name, 'Your doctor') || ' is currently reviewing your symptom questionnaire and medical documents.';
            INSERT INTO public.in_app_notifications (user_id, title, message, type, link)
            VALUES (NEW.patient_id, 'Case Under Review', patient_msg, 'case_update', '/patient-dashboard');

        ELSIF NEW.status = 'report_ready' THEN
            patient_msg := 'Your medical report from Dr. ' || COALESCE(doc_name, 'your doctor') || ' is now ready to view and download!';
            INSERT INTO public.in_app_notifications (user_id, title, message, type, link)
            VALUES (NEW.patient_id, 'Medical Report Ready', patient_msg, 'report_ready', '/patient-dashboard');

        ELSIF NEW.status = 'completed' THEN
            patient_msg := 'Your consultation has been marked completed. You can leave a rating for Dr. ' || COALESCE(doc_name, 'your doctor') || '.';
            INSERT INTO public.in_app_notifications (user_id, title, message, type, link)
            VALUES (NEW.patient_id, 'Consultation Completed', patient_msg, 'info', '/patient-dashboard');
        END IF;
    END IF;

    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_case_status_change ON public.patient_cases;
CREATE TRIGGER on_case_status_change
    BEFORE UPDATE ON public.patient_cases
    FOR EACH ROW EXECUTE FUNCTION public.handle_case_status_change();


-- 4. Report Release Handling
CREATE OR REPLACE FUNCTION public.handle_report_release()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF NEW.status = 'released' AND (OLD.status IS DISTINCT FROM 'released') THEN
        NEW.released_at := now();

        -- Automatically update the parent case status to 'report_ready'
        UPDATE public.patient_cases
        SET status = 'report_ready', updated_at = now()
        WHERE id = NEW.case_id;
    END IF;

    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_report_release ON public.doctor_reports;
CREATE TRIGGER on_report_release
    BEFORE UPDATE ON public.doctor_reports
    FOR EACH ROW EXECUTE FUNCTION public.handle_report_release();


-- 5. Doctor Discovery View with Aggregated Rating & Review Counts
CREATE OR REPLACE VIEW public.doctor_directory_view AS
SELECT 
    dp.id,
    p.full_name,
    p.avatar_url,
    dp.specialty,
    dp.qualifications,
    dp.experience_years,
    dp.languages,
    dp.clinic_location,
    dp.consultation_fee,
    dp.bio,
    dp.verification_status,
    dp.is_available,
    COALESCE(ROUND(AVG(dr.rating)::numeric, 1), 5.0) as average_rating,
    COUNT(dr.id) as review_count
FROM public.doctor_profiles dp
JOIN public.profiles p ON p.id = dp.id
LEFT JOIN public.doctor_ratings dr ON dr.doctor_id = dp.id
GROUP BY 
    dp.id,
    p.full_name,
    p.avatar_url,
    dp.specialty,
    dp.qualifications,
    dp.experience_years,
    dp.languages,
    dp.clinic_location,
    dp.consultation_fee,
    dp.bio,
    dp.verification_status,
    dp.is_available;

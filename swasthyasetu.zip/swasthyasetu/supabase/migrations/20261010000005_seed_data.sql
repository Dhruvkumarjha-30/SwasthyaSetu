-- Migration: 20261010000005_seed_data.sql
-- Project: SwasthyaSetu (स्वास्थ्यसेतु)
-- Description: Realistic demonstration and test data for hackathon presentation and local development.

-- Seed sample doctors (using deterministic UUIDs for test convenience)
DO $$
DECLARE
    doc1_id UUID := '11111111-1111-1111-1111-111111111111';
    doc2_id UUID := '22222222-2222-2222-2222-222222222222';
    doc3_id UUID := '33333333-3333-3333-3333-333333333333';
    doc4_id UUID := '44444444-4444-4444-4444-444444444444';
    patient1_id UUID := '99999999-9999-9999-9999-999999999999';
    case1_id UUID := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
    case2_id UUID := 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
BEGIN

    -- 1. Insert seed doctor auth user stubs into profiles if not already present
    INSERT INTO public.profiles (id, email, full_name, role, phone, preferred_language)
    VALUES 
        (doc1_id, 'dr.asha.verma@swasthyasetu.org', 'Dr. Asha Verma', 'doctor', '+91 98765 43210', 'hi'),
        (doc2_id, 'dr.rohan.mehta@swasthyasetu.org', 'Dr. Rohan Mehta', 'doctor', '+91 98765 43211', 'en'),
        (doc3_id, 'dr.meera.iyer@swasthyasetu.org', 'Dr. Meera Iyer', 'doctor', '+91 98765 43212', 'en'),
        (doc4_id, 'dr.imran.khan@swasthyasetu.org', 'Dr. Imran Khan', 'doctor', '+91 98765 43213', 'hi'),
        (patient1_id, 'ramesh.kumar@example.com', 'Ramesh Kumar (Demo Patient)', 'patient', '+91 91234 56789', 'hi')
    ON CONFLICT (id) DO UPDATE SET
        full_name = EXCLUDED.full_name;

    -- 2. Insert Doctor Profiles
    INSERT INTO public.doctor_profiles (
        id, specialty, qualifications, experience_years, languages, 
        clinic_location, consultation_fee, bio, registration_number, 
        verification_status, is_available
    )
    VALUES
        (
            doc1_id,
            'General Physician',
            'MBBS (KGMC Lucknow)',
            12,
            ARRAY['Hindi', 'English'],
            'Primary Health Centre, Greater Noida, UP',
            300,
            'Passionate about grassroots primary healthcare, managing seasonal viral illnesses, hypertension, and preventive health for rural families.',
            'MCI-UP-48921',
            'verified',
            true
        ),
        (
            doc2_id,
            'Dermatology',
            'MBBS, MD Dermatology (AIIMS Delhi)',
            8,
            ARRAY['English', 'Hindi'],
            'District Hospital, Sector 39, Noida',
            500,
            'Specialist in rural infectious dermatoses, fungal infections, allergic rashes, and occupational eczema in agricultural workers.',
            'DMC-61024',
            'verified',
            true
        ),
        (
            doc3_id,
            'Pulmonology',
            'MBBS, DNB Respiratory Medicine',
            15,
            ARRAY['English', 'Hindi'],
            'Community Care Chest Clinic, Delhi NCR',
            700,
            'Dedicated pulmonologist focusing on chronic bronchitis, biomass smoke exposure symptoms, seasonal asthma, and post-viral cough management.',
            'DMC-33190',
            'verified',
            true
        ),
        (
            doc4_id,
            'Pediatrics',
            'MBBS, DCH (Child Health)',
            6,
            ARRAY['Hindi', 'Urdu'],
            'Rural Child Wellness Clinic, Bulandshahr',
            400,
            'Experienced pediatrician managing childhood respiratory infections, immunization guidance, and pediatric nutritional wellness.',
            'UPMC-72015',
            'verified',
            true
        )
    ON CONFLICT (id) DO UPDATE SET
        verification_status = 'verified',
        is_available = true;

    -- 3. Seed Sample Patient Case (Completed with Doctor Report)
    INSERT INTO public.patient_cases (
        id, patient_id, assigned_doctor_id, status, chief_complaint, 
        symptoms, duration, questionnaire_responses, emergency_flag, patient_notes
    )
    VALUES (
        case1_id,
        patient1_id,
        doc1_id,
        'report_ready',
        'Moderate fever and wet cough for 4 days',
        ARRAY['Fever', 'Cough', 'Body ache'],
        '3–7 days',
        '{
            "Fever: when did it start?": "3–7 days",
            "Fever: how is it changing?": "Staying the same",
            "Have you taken any medicine for it?": "Paracetamol 500mg once yesterday",
            "Cough: what is it like?": "With phlegm",
            "Is breathing difficult even when resting?": "No"
        }'::jsonb,
        false,
        'Feeling weak in the evenings, throat is also slightly sore.'
    )
    ON CONFLICT (id) DO NOTHING;

    -- 4. Seed Doctor Report for Case 1
    INSERT INTO public.doctor_reports (
        id, case_id, doctor_id, patient_id, clinical_summary, diagnosis_notes,
        prescriptions, dietary_lifestyle_advice, follow_up_recommendations,
        is_emergency_referral, status, version, released_at
    )
    VALUES (
        'rrrrrrrr-rrrr-rrrr-rrrr-rrrrrrrrrrrr',
        case1_id,
        doc1_id,
        patient1_id,
        'Patient presents with a 4-day history of low-to-moderate fever, productive cough, and mild generalized myalgia. No red flags or acute respiratory distress noted.',
        'Acute Upper Respiratory Viral Infection with mild tracheobronchitis. No signs of consolidation or severe lower respiratory tract involvement.',
        '[
            {"medicine": "Paracetamol 650mg", "dosage": "1 tablet SOS if fever > 100°F (max 3 times/day)", "duration": "3 days"},
            {"medicine": "Ambroxol + Levocetirizine syrup", "dosage": "5ml twice daily after food", "duration": "5 days"},
            {"medicine": "Steam inhalation with plain water", "dosage": "Twice daily for 10 minutes", "duration": "5 days"}
        ]'::jsonb,
        'Drink plenty of warm fluids (lukewarm water, tulsi/ginger tea). Avoid cold foods and dusty farm environments. Rest adequately for 48 hours.',
        'If fever persists beyond 3 days or you develop chest pain or breathing difficulty, visit the nearest Community Health Centre immediately.',
        false,
        'released',
        1,
        now() - INTERVAL '2 hours'
    )
    ON CONFLICT (id) DO NOTHING;

    -- 5. Seed Rating for Doctor 1 from Patient 1
    INSERT INTO public.doctor_ratings (case_id, patient_id, doctor_id, rating, review_text)
    VALUES (
        case1_id,
        patient1_id,
        doc1_id,
        5,
        'Dr. Asha explained everything very clearly in Hindi. The report and medicines helped my fever reduce within 2 days. Very grateful for this service.'
    )
    ON CONFLICT (case_id, patient_id) DO NOTHING;

    -- 6. Seed Case 2 (Awaiting review, for Doctor Dashboard demo)
    INSERT INTO public.patient_cases (
        id, patient_id, assigned_doctor_id, status, chief_complaint,
        symptoms, duration, questionnaire_responses, emergency_flag, patient_notes
    )
    VALUES (
        case2_id,
        patient1_id,
        doc1_id,
        'assigned',
        'Itchy red skin rash on hands after handling fertilizer',
        ARRAY['Skin concerns'],
        '1–2 days',
        '{
            "Where on the body is the skin concern?": "Arms or hands",
            "Skin: how long has it been there?": "1–2 days",
            "Does it itch or hurt?": "Itches"
        }'::jsonb,
        false,
        'Applied coconut oil but itching still persists.'
    )
    ON CONFLICT (id) DO NOTHING;

END $$;
